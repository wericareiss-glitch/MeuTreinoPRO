/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  MuscleGroup,
  SplitOption,
  StrategyOption,
  LevelOption,
  EquipmentRequirement,
  GeneratedWorkoutRoutine,
  WorkoutItem,
  UserProfile,
} from '../types/workout';
import { EXERCISE_DATABASE } from '../data/exerciseDatabase';
import { calculateDefaultBudget, getPresetWeights } from './auth';

interface RoutineGeneratorParams {
  user: UserProfile;
  split?: SplitOption;
  strategy?: StrategyOption;
  exercisesPerMuscle?: 1 | 2;
  manualWeeklySets?: number;
  level?: LevelOption;
  equip?: EquipmentRequirement;
  restSeconds?: number;
}

interface DayPlan {
  letter: string;
  name: string;
  subtitle: string;
  split: SplitOption;
  muscleGroups: MuscleGroup[];
}

export function generateWeeklyRoutines(params: RoutineGeneratorParams): GeneratedWorkoutRoutine[] {
  const { user } = params;
  const frequency = user.frequency || 4;
  const focus = user.focus || 'v_taper';
  const level = params.level || user.level || 'beginner';
  const equip = params.equip || 'full_gym';
  const strategy = params.strategy || 'synergy';
  const restSeconds = params.restSeconds || 30;

  // 1. Determina a divisão muscular solicitada (Split)
  const requestedSplit: SplitOption = params.split || user.preferredSplit || (
    focus === 'glutes' 
      ? 'lower' 
      : frequency <= 3 
      ? 'fullbody' 
      : 'upper_lower'
  );

  // 2. Quantidade de exercícios por músculo: 1 (Foco Principal) ou 2 (Base + Complementar)
  const exercisesPerMuscle: 1 | 2 = params.exercisesPerMuscle || user.exercisesPerMuscle || (strategy === 'single' ? 1 : 2);

  // 3. Orçamento semanal total de séries (Controle Manual prioritário ou padrão calculado via weeklyBudget)
  const defaultWeeklyBudget = calculateDefaultBudget(level, user.gender || 'male');
  const totalWeeklyBudget = params.manualWeeklySets && params.manualWeeklySets > 0
    ? params.manualWeeklySets
    : (user.weeklyBudget && user.weeklyBudget > 0 ? user.weeklyBudget : defaultWeeklyBudget);

  const letters = ['A', 'B', 'C', 'D', 'E', 'F'];
  let dayPlans: DayPlan[] = [];

  // =========================================================================
  // CASO 1: DIVISÃO FULL BODY (Corpo Inteiro em Cada Sessão da Semana)
  // =========================================================================
  if (requestedSplit === 'fullbody') {
    const fullBodyBaseMuscles: MuscleGroup[] = [
      'quadriceps',
      'hamstrings',
      'glutes',
      'chest',
      'back',
      'shoulders',
      'rear_delts',
      'triceps',
      'biceps',
      'calves',
      'abs',
    ];

    const daysCount = Math.min(Math.max(2, frequency), 6);
    dayPlans = Array.from({ length: daysCount }).map((_, idx) => ({
      letter: letters[idx],
      name: `Treino ${letters[idx]}`,
      subtitle: 'Full Body · Corpo Inteiro',
      split: 'fullbody',
      muscleGroups: [...fullBodyBaseMuscles],
    }));
  }

  // =========================================================================
  // CASO 2: DIVISÃO ABCDE (Divisão Clássica de 5 Dias por Músculo)
  // =========================================================================
  else if (requestedSplit === 'abcde') {
    if (frequency <= 4) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'ABCDE · Peitoral, Tríceps & Abdômen',
          split: 'abcde',
          muscleGroups: ['chest', 'triceps', 'abs'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'ABCDE · Costas, Posterior & Bíceps',
          split: 'abcde',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'ABCDE · Pernas Completas & Panturrilhas',
          split: 'abcde',
          muscleGroups: ['quadriceps', 'hamstrings', 'glutes', 'calves'],
        },
        {
          letter: 'D',
          name: 'Treino D',
          subtitle: 'ABCDE · Ombros, Deltoides & Braços',
          split: 'abcde',
          muscleGroups: ['shoulders', 'rear_delts', 'biceps', 'triceps', 'abs'],
        },
      ];
    } else if (frequency === 5) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'ABCDE · Peitoral & Abdômen',
          split: 'abcde',
          muscleGroups: ['chest', 'abs'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'ABCDE · Costas & Deltoide Posterior',
          split: 'abcde',
          muscleGroups: ['back', 'rear_delts'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'ABCDE · Pernas & Panturrilhas',
          split: 'abcde',
          muscleGroups: ['quadriceps', 'hamstrings', 'glutes', 'calves'],
        },
        {
          letter: 'D',
          name: 'Treino D',
          subtitle: 'ABCDE · Ombros & Trapézio',
          split: 'abcde',
          muscleGroups: ['shoulders', 'rear_delts', 'abs'],
        },
        {
          letter: 'E',
          name: 'Treino E',
          subtitle: 'ABCDE · Braços (Bíceps & Tríceps)',
          split: 'abcde',
          muscleGroups: ['biceps', 'triceps'],
        },
      ];
    } else {
      // 6 dias ABCDE + Pernas/Posterior
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'ABCDE · Peitoral & Abdômen',
          split: 'abcde',
          muscleGroups: ['chest', 'abs'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'ABCDE · Costas & Deltoide Posterior',
          split: 'abcde',
          muscleGroups: ['back', 'rear_delts'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'ABCDE · Quadríceps & Panturrilhas',
          split: 'abcde',
          muscleGroups: ['quadriceps', 'glutes', 'calves'],
        },
        {
          letter: 'D',
          name: 'Treino D',
          subtitle: 'ABCDE · Ombros & Trapézio',
          split: 'abcde',
          muscleGroups: ['shoulders', 'rear_delts', 'abs'],
        },
        {
          letter: 'E',
          name: 'Treino E',
          subtitle: 'ABCDE · Braços (Bíceps & Tríceps)',
          split: 'abcde',
          muscleGroups: ['biceps', 'triceps'],
        },
        {
          letter: 'F',
          name: 'Treino F',
          subtitle: 'ABCDE · Posterior de Coxa & Glúteos',
          split: 'abcde',
          muscleGroups: ['hamstrings', 'glutes', 'calves'],
        },
      ];
    }
  }

  // =========================================================================
  // CASO 3: DIVISÃO LOWER (Foco Inferiores e Glúteos)
  // =========================================================================
  else if (requestedSplit === 'lower') {
    if (frequency === 2) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Lower · Quadríceps, Glúteos & Panturrilhas',
          split: 'lower',
          muscleGroups: ['quadriceps', 'glutes', 'calves'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Lower · Posterior de Coxa, Glúteos & Abdômen',
          split: 'lower',
          muscleGroups: ['hamstrings', 'glutes', 'calves', 'abs'],
        },
      ];
    } else if (frequency === 3) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Lower · Foco Quadríceps & Panturrilhas',
          split: 'lower',
          muscleGroups: ['quadriceps', 'glutes', 'calves'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Lower · Foco Glúteos & Isquiotibiais',
          split: 'lower',
          muscleGroups: ['glutes', 'hamstrings', 'abs'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'Lower · Pernas Globais & Panturrilhas',
          split: 'lower',
          muscleGroups: ['quadriceps', 'hamstrings', 'glutes', 'calves', 'abs'],
        },
      ];
    } else if (frequency === 4) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Lower · Quadríceps & Panturrilhas',
          split: 'lower',
          muscleGroups: ['quadriceps', 'glutes', 'calves'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Lower · Isquiotibiais & Glúteos',
          split: 'lower',
          muscleGroups: ['hamstrings', 'glutes', 'abs'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'Lower · Foco Glúteos & Quadríceps',
          split: 'lower',
          muscleGroups: ['glutes', 'quadriceps', 'calves'],
        },
        {
          letter: 'D',
          name: 'Treino D',
          subtitle: 'Lower · Posterior de Coxa & Core',
          split: 'lower',
          muscleGroups: ['hamstrings', 'glutes', 'calves', 'abs'],
        },
      ];
    } else {
      // 5+ dias Lower
      const daysCount = Math.min(frequency, 6);
      dayPlans = Array.from({ length: daysCount }).map((_, idx) => ({
        letter: letters[idx],
        name: `Treino ${letters[idx]}`,
        subtitle: idx % 2 === 0 ? 'Lower · Foco Quadríceps & Glúteos' : 'Lower · Foco Isquiotibiais & Core',
        split: 'lower',
        muscleGroups: idx % 2 === 0
          ? ['quadriceps', 'glutes', 'calves']
          : ['hamstrings', 'glutes', 'calves', 'abs'],
      }));
    }
  }

  // =========================================================================
  // CASO 4: DIVISÃO UPPER (Foco Superiores)
  // =========================================================================
  else if (requestedSplit === 'upper') {
    if (frequency === 2) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Upper · Peitoral, Deltoides & Tríceps',
          split: 'upper',
          muscleGroups: ['chest', 'shoulders', 'triceps'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Upper · Costas, Posterior & Bíceps',
          split: 'upper',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
      ];
    } else if (frequency === 3) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Upper · Peitoral, Ombros & Tríceps',
          split: 'upper',
          muscleGroups: ['chest', 'shoulders', 'triceps'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Upper · Costas, Posterior & Bíceps',
          split: 'upper',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'Upper · Superiores Globais & Braços',
          split: 'upper',
          muscleGroups: ['chest', 'back', 'shoulders', 'biceps', 'triceps'],
        },
      ];
    } else if (frequency === 4) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Upper · Peitoral & Deltoide Lateral',
          split: 'upper',
          muscleGroups: ['chest', 'shoulders', 'triceps'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Upper · Costas & Deltoide Posterior',
          split: 'upper',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'Upper · Peito, Ombros & Tríceps',
          split: 'upper',
          muscleGroups: ['chest', 'shoulders', 'triceps'],
        },
        {
          letter: 'D',
          name: 'Treino D',
          subtitle: 'Upper · Costas, Posterior & Bíceps',
          split: 'upper',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
      ];
    } else {
      // 5+ dias Upper
      const daysCount = Math.min(frequency, 6);
      dayPlans = Array.from({ length: daysCount }).map((_, idx) => ({
        letter: letters[idx],
        name: `Treino ${letters[idx]}`,
        subtitle: idx % 2 === 0 ? 'Upper · Empurrar & Deltoides' : 'Upper · Puxar & Braços',
        split: 'upper',
        muscleGroups: idx % 2 === 0
          ? ['chest', 'shoulders', 'triceps']
          : ['back', 'rear_delts', 'biceps'],
      }));
    }
  }

  // =========================================================================
  // CASO 5: DIVISÃO LEGS (Pernas Isoladas)
  // =========================================================================
  else if (requestedSplit === 'legs') {
    const daysCount = Math.min(Math.max(2, frequency), 6);
    dayPlans = Array.from({ length: daysCount }).map((_, idx) => ({
      letter: letters[idx],
      name: `Treino ${letters[idx]}`,
      subtitle: idx % 2 === 0 ? 'Legs · Foco Quadríceps & Panturrilhas' : 'Legs · Foco Isquiotibiais & Glúteos',
      split: 'legs',
      muscleGroups: idx % 2 === 0
        ? ['quadriceps', 'glutes', 'calves']
        : ['hamstrings', 'glutes', 'calves', 'abs'],
    }));
  }

  // =========================================================================
  // CASO 6: DIVISÃO PUSH / PULL / LEGS (PPL)
  // =========================================================================
  else if (requestedSplit === 'ppl' || requestedSplit === 'push' || requestedSplit === 'pull') {
    if (frequency === 3) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Push · Peitoral, Ombros & Tríceps',
          split: 'push',
          muscleGroups: ['chest', 'shoulders', 'triceps'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Pull · Costas, Posterior de Ombro & Bíceps',
          split: 'pull',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'Legs · Pernas Completas & Abdômen',
          split: 'legs',
          muscleGroups: ['quadriceps', 'hamstrings', 'glutes', 'calves', 'abs'],
        },
      ];
    } else if (frequency === 4) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Push · Peitoral, Ombros & Tríceps',
          split: 'push',
          muscleGroups: ['chest', 'shoulders', 'triceps'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Pull · Costas, Posterior & Bíceps',
          split: 'pull',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'Legs · Pernas Completas & Panturrilhas',
          split: 'legs',
          muscleGroups: ['quadriceps', 'hamstrings', 'glutes', 'calves'],
        },
        {
          letter: 'D',
          name: 'Treino D',
          subtitle: 'Upper · Superiores & Core',
          split: 'upper',
          muscleGroups: ['chest', 'back', 'shoulders', 'biceps', 'triceps', 'abs'],
        },
      ];
    } else if (frequency === 5) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Push · Peitoral, Ombros & Tríceps',
          split: 'push',
          muscleGroups: ['chest', 'shoulders', 'triceps'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Pull · Costas, Posterior & Bíceps',
          split: 'pull',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'Legs · Pernas Completas & Panturrilhas',
          split: 'legs',
          muscleGroups: ['quadriceps', 'hamstrings', 'glutes', 'calves'],
        },
        {
          letter: 'D',
          name: 'Treino D',
          subtitle: 'Upper · Superiores Globais',
          split: 'upper',
          muscleGroups: ['back', 'chest', 'shoulders', 'triceps', 'biceps'],
        },
        {
          letter: 'E',
          name: 'Treino E',
          subtitle: 'Lower · Inferiores & Abdômen',
          split: 'lower',
          muscleGroups: ['glutes', 'hamstrings', 'quadriceps', 'calves', 'abs'],
        },
      ];
    } else {
      // 6x PPL
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Push · Peitoral, Ombros & Tríceps',
          split: 'push',
          muscleGroups: ['chest', 'shoulders', 'triceps'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Pull · Costas, Posterior & Bíceps',
          split: 'pull',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'Legs · Quadríceps, Glúteos & Panturrilhas',
          split: 'legs',
          muscleGroups: ['quadriceps', 'glutes', 'calves'],
        },
        {
          letter: 'D',
          name: 'Treino D',
          subtitle: 'Push · Peitoral Superior, Deltoides & Tríceps',
          split: 'push',
          muscleGroups: ['chest', 'shoulders', 'triceps'],
        },
        {
          letter: 'E',
          name: 'Treino E',
          subtitle: 'Pull · Remadas, Puxadas & Bíceps',
          split: 'pull',
          muscleGroups: ['back', 'rear_delts', 'biceps'],
        },
        {
          letter: 'F',
          name: 'Treino F',
          subtitle: 'Legs · Glúteos, Posterior de Coxa & Core',
          split: 'legs',
          muscleGroups: ['hamstrings', 'glutes', 'calves', 'abs'],
        },
      ];
    }
  }

  // =========================================================================
  // CASO 7: DIVISÃO UPPER / LOWER (Padrão)
  // =========================================================================
  else {
    if (frequency === 2) {
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Upper · Superiores',
          split: 'upper',
          muscleGroups: ['chest', 'back', 'shoulders', 'biceps', 'triceps'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Lower · Inferiores & Core',
          split: 'lower',
          muscleGroups: ['quadriceps', 'hamstrings', 'glutes', 'calves', 'abs'],
        },
      ];
    } else if (frequency === 3) {
      if (focus === 'glutes') {
        dayPlans = [
          {
            letter: 'A',
            name: 'Treino A',
            subtitle: 'Lower · Glúteos & Quadríceps',
            split: 'lower',
            muscleGroups: ['glutes', 'quadriceps', 'calves', 'abs'],
          },
          {
            letter: 'B',
            name: 'Treino B',
            subtitle: 'Upper · Costas, Peitoral & Braços',
            split: 'upper',
            muscleGroups: ['back', 'chest', 'shoulders', 'triceps', 'biceps'],
          },
          {
            letter: 'C',
            name: 'Treino C',
            subtitle: 'Lower · Glúteos & Isquiotibiais',
            split: 'lower',
            muscleGroups: ['glutes', 'hamstrings', 'calves', 'abs'],
          },
        ];
      } else {
        dayPlans = [
          {
            letter: 'A',
            name: 'Treino A',
            subtitle: 'Upper · Peitoral, Costas & Ombros',
            split: 'upper',
            muscleGroups: ['chest', 'back', 'shoulders', 'triceps'],
          },
          {
            letter: 'B',
            name: 'Treino B',
            subtitle: 'Lower · Pernas Completas & Abdômen',
            split: 'lower',
            muscleGroups: ['quadriceps', 'hamstrings', 'glutes', 'calves', 'abs'],
          },
          {
            letter: 'C',
            name: 'Treino C',
            subtitle: 'Upper · Costas, Ombros, Peito & Bíceps',
            split: 'upper',
            muscleGroups: ['back', 'chest', 'shoulders', 'rear_delts', 'biceps'],
          },
        ];
      }
    } else if (frequency === 4) {
      if (focus === 'glutes') {
        dayPlans = [
          {
            letter: 'A',
            name: 'Treino A',
            subtitle: 'Lower · Glúteos & Quadríceps',
            split: 'lower',
            muscleGroups: ['glutes', 'quadriceps', 'calves'],
          },
          {
            letter: 'B',
            name: 'Treino B',
            subtitle: 'Upper · Costas, Ombros & Peitoral',
            split: 'upper',
            muscleGroups: ['back', 'shoulders', 'chest', 'triceps', 'biceps'],
          },
          {
            letter: 'C',
            name: 'Treino C',
            subtitle: 'Lower · Glúteos & Isquiotibiais',
            split: 'lower',
            muscleGroups: ['glutes', 'hamstrings', 'calves', 'abs'],
          },
          {
            letter: 'D',
            name: 'Treino D',
            subtitle: 'Upper · Peitoral, Deltoides & Core',
            split: 'upper',
            muscleGroups: ['chest', 'shoulders', 'back', 'biceps', 'abs'],
          },
        ];
      } else {
        dayPlans = [
          {
            letter: 'A',
            name: 'Treino A',
            subtitle: 'Upper · Peitoral, Costas, Ombros & Tríceps',
            split: 'upper',
            muscleGroups: ['chest', 'back', 'shoulders', 'triceps'],
          },
          {
            letter: 'B',
            name: 'Treino B',
            subtitle: 'Lower · Quadríceps, Glúteos & Panturrilhas',
            split: 'lower',
            muscleGroups: ['quadriceps', 'glutes', 'calves', 'abs'],
          },
          {
            letter: 'C',
            name: 'Treino C',
            subtitle: 'Upper · Costas, Ombros, Bíceps & Peito',
            split: 'upper',
            muscleGroups: ['back', 'shoulders', 'rear_delts', 'biceps', 'chest'],
          },
          {
            letter: 'D',
            name: 'Treino D',
            subtitle: 'Lower · Isquiotibiais, Glúteos & Panturrilhas',
            split: 'lower',
            muscleGroups: ['hamstrings', 'glutes', 'quadriceps', 'calves'],
          },
        ];
      }
    } else {
      // 5+ dias Upper/Lower
      dayPlans = [
        {
          letter: 'A',
          name: 'Treino A',
          subtitle: 'Upper · Peitoral, Costas & Ombros',
          split: 'upper',
          muscleGroups: ['chest', 'back', 'shoulders', 'triceps'],
        },
        {
          letter: 'B',
          name: 'Treino B',
          subtitle: 'Lower · Quadríceps & Glúteos',
          split: 'lower',
          muscleGroups: ['quadriceps', 'glutes', 'calves'],
        },
        {
          letter: 'C',
          name: 'Treino C',
          subtitle: 'Upper · Dorsal, Ombros & Braços',
          split: 'upper',
          muscleGroups: ['back', 'shoulders', 'biceps', 'rear_delts'],
        },
        {
          letter: 'D',
          name: 'Treino D',
          subtitle: 'Lower · Isquiotibiais, Glúteos & Abdômen',
          split: 'lower',
          muscleGroups: ['hamstrings', 'glutes', 'calves', 'abs'],
        },
        {
          letter: 'E',
          name: 'Treino E',
          subtitle: 'Full Body · Compostos Globais',
          split: 'fullbody',
          muscleGroups: ['chest', 'back', 'quadriceps', 'biceps', 'triceps'],
        },
      ];
    }
  }

  // =========================================================================
  // EQUALIZAÇÃO EXATA DO VOLUME SEMANAL (SEM LIMITES FIXOS ARBITRÁRIOS)
  // Distribui 100% do totalWeeklyBudget entre os músculos participantes
  // =========================================================================
  const allTrainedMuscles = Array.from(new Set(dayPlans.flatMap((p) => p.muscleGroups)));
  const baseWeights = getPresetWeights(focus);

  const relevantWeights: Record<MuscleGroup, number> = {} as Record<MuscleGroup, number>;
  allTrainedMuscles.forEach((m) => {
    relevantWeights[m] = baseWeights[m] || 8;
  });
  const sumWeights = Object.values(relevantWeights).reduce((a, b) => a + b, 0);

  const muscleBudgets: Record<MuscleGroup, number> = {} as Record<MuscleGroup, number>;
  let allocated = 0;
  allTrainedMuscles.forEach((m) => {
    const raw = Math.round((relevantWeights[m] / (sumWeights || 1)) * totalWeeklyBudget);
    muscleBudgets[m] = Math.max(1, raw);
    allocated += muscleBudgets[m];
  });

  // Ajuste fino para bater exatamente o totalWeeklyBudget do usuário
  let diff = totalWeeklyBudget - allocated;
  let pIdx = 0;
  while (diff !== 0 && allTrainedMuscles.length > 0) {
    const targetM = allTrainedMuscles[pIdx % allTrainedMuscles.length];
    if (diff > 0) {
      muscleBudgets[targetM] += 1;
      diff -= 1;
    } else if (diff < 0 && muscleBudgets[targetM] > 1) {
      muscleBudgets[targetM] -= 1;
      diff += 1;
    } else {
      break;
    }
    pIdx++;
  }

  // =========================================================================
  // MONTAGEM DOS ITENS DE EXERCÍCIO
  // Cada músculo tem suas séries semanais divididas equitativamente pelos treinos
  // =========================================================================
  const routines: GeneratedWorkoutRoutine[] = dayPlans.map((plan, planIdx) => {
    const items: WorkoutItem[] = [];

    plan.muscleGroups.forEach((mKey) => {
      const muscleList = EXERCISE_DATABASE[mKey] || [];
      // Filtra por equipamento disponível
      let pool = muscleList.filter((e) => {
        if (equip === 'full_gym') return true;
        if (equip === 'cables_free') return e.equip.includes('cables_free') || e.equip.includes('dumbbells_only');
        return e.equip.includes('dumbbells_only');
      });

      if (pool.length === 0) pool = muscleList;
      if (pool.length === 0) return;

      const weeklyMuscleBudget = muscleBudgets[mKey] || 8;
      const occurrences = dayPlans.filter((p) => p.muscleGroups.includes(mKey));
      const timesMuscleTrained = Math.max(1, occurrences.length);

      // Distribuição equitativa exata de séries:
      // divide o volume semanal pelo número de sessões em que o músculo participa,
      // distribuindo as sobras de forma rotativa entre os treinos.
      const baseSets = Math.floor(weeklyMuscleBudget / timesMuscleTrained);
      const remainder = weeklyMuscleBudget % timesMuscleTrained;
      const mIdx = plan.muscleGroups.indexOf(mKey);
      const getsExtra = ((planIdx + mIdx) % timesMuscleTrained) < remainder;
      const dailyMuscleSets = Math.max(1, baseSets + (getsExtra ? 1 : 0));

      const repRange = '8 a 10';
      const rir = level === 'beginner' ? 'RIR 2' : level === 'intermediate' ? 'RIR 1-2' : 'RIR 0-1';

      if (exercisesPerMuscle === 1) {
        // 1 Exercício por músculo:
        // Rotaciona a escolha do exercício com base no índice do treino para garantir variações motoras
        const exIndex = planIdx % pool.length;
        const chosen = pool[exIndex] || pool[0];

        items.push({
          id: `${plan.letter.toLowerCase()}_${mKey}_${chosen.id}`,
          muscleKey: mKey,
          exercise: chosen,
          sets: dailyMuscleSets,
          reps: repRange,
          rir: rir,
          rest: restSeconds,
          tagRole: 'Principal',
        });
      } else {
        // 2 Exercícios por músculo: Base (Principal) + Complementar
        const baseIndex = (planIdx * 2) % pool.length;
        let mainEx = pool[baseIndex] || pool[0];

        // Busca exercício complementar com perfil biomecânico diferente (encurtamento ou tensão contínua)
        let compEx = pool.find(
          (e, idx) =>
            idx !== baseIndex &&
            e.id !== mainEx.id &&
            (e.profile.toLowerCase().includes('encurtamento') || e.profile.toLowerCase().includes('contínua'))
        );

        if (!compEx) {
          const compIndex = (baseIndex + 1) % pool.length;
          compEx = pool[compIndex].id !== mainEx.id ? pool[compIndex] : pool[0];
        }

        if (dailyMuscleSets === 1 || compEx.id === mainEx.id) {
          items.push({
            id: `${plan.letter.toLowerCase()}_${mKey}_main_${mainEx.id}`,
            muscleKey: mKey,
            exercise: mainEx,
            sets: dailyMuscleSets,
            reps: '8 a 10',
            rir: rir,
            rest: restSeconds,
            tagRole: 'Principal',
          });
        } else {
          // Divisão proporcional exata: soma(mainSets + compSets) === dailyMuscleSets
          const mainSets = dailyMuscleSets === 2 ? 1 : Math.max(1, Math.ceil(dailyMuscleSets * 0.6));
          const compSets = dailyMuscleSets - mainSets;

          items.push({
            id: `${plan.letter.toLowerCase()}_${mKey}_main_${mainEx.id}`,
            muscleKey: mKey,
            exercise: mainEx,
            sets: mainSets,
            reps: '8 a 10',
            rir: rir,
            rest: restSeconds,
            tagRole: 'Base',
          });

          items.push({
            id: `${plan.letter.toLowerCase()}_${mKey}_comp_${compEx.id}`,
            muscleKey: mKey,
            exercise: compEx,
            sets: compSets,
            reps: '10 a 12',
            rir: level === 'beginner' ? 'RIR 1' : 'RIR 0-1',
            rest: restSeconds,
            tagRole: 'Complementar',
          });
        }
      }
    });

    const totalSets = items.reduce((acc, curr) => acc + curr.sets, 0);
    const estimatedMinutes = Math.round((totalSets * (45 + restSeconds)) / 60);

    return {
      id: `routine_${plan.letter.toLowerCase()}`,
      letter: plan.letter,
      name: plan.name,
      subtitle: plan.subtitle,
      split: plan.split,
      muscleGroups: plan.muscleGroups,
      items,
      totalSets,
      estimatedMinutes: Math.max(25, estimatedMinutes),
    };
  });

  return routines;
}

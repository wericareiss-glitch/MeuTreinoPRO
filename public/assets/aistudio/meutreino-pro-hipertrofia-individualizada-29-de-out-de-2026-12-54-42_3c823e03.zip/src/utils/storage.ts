/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export const safeStorage = {
  cache: {} as Record<string, string>,
  get<T>(key: string, defaultValue: T): T {
    try {
      const item = localStorage.getItem(key);
      if (item === null) return defaultValue;
      return JSON.parse(item) as T;
    } catch {
      if (this.cache[key]) {
        try {
          return JSON.parse(this.cache[key]) as T;
        } catch {
          return defaultValue;
        }
      }
      return defaultValue;
    }
  },
  set(key: string, value: unknown): void {
    try {
      const serialized = JSON.stringify(value);
      localStorage.setItem(key, serialized);
      this.cache[key] = serialized;
    } catch {
      this.cache[key] = JSON.stringify(value);
    }
  },
  remove(key: string): void {
    try {
      localStorage.removeItem(key);
      delete this.cache[key];
    } catch {
      delete this.cache[key];
    }
  },
};

/**
 * Calculates estimated 1 Rep Max using Epley formula: w * (1 + r / 30)
 */
export function calculate1RM(weightStr: string, repsStr: string): number | null {
  const weight = parseFloat(weightStr);
  const reps = parseInt(repsStr, 10);
  if (isNaN(weight) || isNaN(reps) || weight <= 0 || reps <= 0) return null;
  if (reps === 1) return Math.round(weight);
  return Math.round(weight * (1 + reps / 30));
}

/**
 * Calculates estimated 6 Rep Max based on 1RM:
 * 6RM is approximately 85% of 1RM (or 1RM / 1.2)
 */
export function calculate6RM(weightStr: string, repsStr: string): number | null {
  const oneRm = calculate1RM(weightStr, repsStr);
  if (!oneRm) return null;
  return Math.round(oneRm / 1.2);
}

/**
 * Calculates total session volume load: sum(weight * reps)
 */
export function calculateVolumeLoad(logs: Record<string, { weight: string; reps: string; done: boolean }>): number {
  let total = 0;
  for (const key of Object.keys(logs)) {
    const item = logs[key];
    if (item.done) {
      const w = parseFloat(item.weight) || 0;
      const r = parseInt(item.reps, 10) || 0;
      total += w * r;
    }
  }
  return Math.round(total);
}

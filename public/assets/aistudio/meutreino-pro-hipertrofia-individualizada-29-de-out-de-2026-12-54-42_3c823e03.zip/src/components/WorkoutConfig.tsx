/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sliders, Layers, Award, Sparkles, Clock, Hash, Dumbbell } from 'lucide-react';
import { SplitOption, LevelOption, EquipmentRequirement } from '../types/workout';

interface WorkoutConfigProps {
  split: SplitOption;
  setSplit: (s: SplitOption) => void;
  exercisesPerMuscle: 1 | 2;
  setExercisesPerMuscle: (n: 1 | 2) => void;
  weeklyBudget: number;
  setWeeklyBudget: (b: number) => void;
  level: LevelOption;
  setLevel: (l: LevelOption) => void;
  equip: EquipmentRequirement;
  setEquip: (e: EquipmentRequirement) => void;
  restSeconds: number;
  setRestSeconds: (s: number) => void;
}

export const WorkoutConfig: React.FC<WorkoutConfigProps> = ({
  split,
  setSplit,
  exercisesPerMuscle,
  setExercisesPerMuscle,
  weeklyBudget,
  setWeeklyBudget,
  level,
  setLevel,
  equip,
  setEquip,
  restSeconds,
  setRestSeconds,
}) => {
  return (
    <div className="bg-[#101828] border border-[#1e2c45] rounded-3xl p-4 sm:p-5 shadow-xl shadow-black/30 mb-6">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-2">
        <div className="flex items-center gap-2">
          <Sliders className="w-4 h-4 text-emerald-400" />
          <h2 className="text-xs sm:text-sm font-bold text-emerald-400 tracking-wider uppercase">
            Parâmetros de Geração de Treino
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20">
            Total Semanal: {weeklyBudget} séries
          </span>
          <span className="text-[11px] font-mono font-bold text-sky-400 bg-sky-500/10 px-2 py-0.5 rounded-lg border border-sky-500/20">
            Descanso: {restSeconds}s
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* 1. Divisão Muscular (Split) */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5 text-slate-500" />
            Divisão Muscular
          </label>
          <select
            value={split}
            onChange={(e) => setSplit(e.target.value as SplitOption)}
            className="w-full bg-[#0d1424] border border-[#223352] text-slate-200 text-xs sm:text-sm rounded-xl px-3 py-2.5 font-medium focus:outline-none focus:border-emerald-500 transition-colors cursor-pointer"
          >
            <option value="fullbody">Full Body (Corpo Inteiro)</option>
            <option value="abcde">ABCDE (5 Dias por Músculo)</option>
            <option value="upper_lower">Upper / Lower (Superiores & Inferiores)</option>
            <option value="ppl">Push / Pull / Legs (PPL)</option>
            <option value="lower">Lower (Foco Inferiores & Glúteos)</option>
            <option value="upper">Upper (Foco Superiores)</option>
            <option value="legs">Legs (Pernas Isoladas)</option>
            <option value="push">Push (Empurrar)</option>
            <option value="pull">Pull (Puxar)</option>
          </select>
        </div>

        {/* 2. Quantidade de Exercícios por Músculo (1 ou 2: Base + Complementar) */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
            <Dumbbell className="w-3.5 h-3.5 text-emerald-400" />
            Exercícios por Músculo
          </label>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => setExercisesPerMuscle(1)}
              className={`py-2 px-2 rounded-xl border text-xs font-bold transition-all cursor-pointer flex flex-col items-center justify-center ${
                exercisesPerMuscle === 1
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/60 shadow-md font-black'
                  : 'bg-[#0d1424] text-slate-400 border-[#223352] hover:text-white'
              }`}
            >
              <span>1 Exercício</span>
              <span className="text-[9px] text-slate-400 font-normal">Foco Principal</span>
            </button>
            <button
              type="button"
              onClick={() => setExercisesPerMuscle(2)}
              className={`py-2 px-2 rounded-xl border text-xs font-bold transition-all cursor-pointer flex flex-col items-center justify-center ${
                exercisesPerMuscle === 2
                  ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/60 shadow-md font-black'
                  : 'bg-[#0d1424] text-slate-400 border-[#223352] hover:text-white'
              }`}
            >
              <span>2 Exercícios</span>
              <span className="text-[9px] text-emerald-400 font-normal">Base + Complementar</span>
            </button>
          </div>
        </div>

        {/* 3. Controle Manual de Séries Semanais */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Hash className="w-3.5 h-3.5 text-amber-400" />
              Séries Semanais (Manual)
            </span>
            <span className="text-[11px] font-mono font-bold text-amber-300">
              {weeklyBudget} séries/sem
            </span>
          </label>
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setWeeklyBudget(Math.max(10, weeklyBudget - 5))}
              className="w-8 h-10 rounded-xl bg-[#0d1424] border border-[#223352] text-slate-300 hover:text-white font-mono font-bold text-sm flex items-center justify-center hover:bg-slate-800 cursor-pointer"
              title="Diminuir 5 séries"
            >
              -5
            </button>
            <input
              type="number"
              min={10}
              max={300}
              step={1}
              value={weeklyBudget}
              onChange={(e) => setWeeklyBudget(Math.max(10, parseInt(e.target.value, 10) || 10))}
              className="w-full bg-[#0d1424] border border-[#223352] text-amber-300 text-center font-mono font-bold text-sm rounded-xl px-2 py-2 focus:outline-none focus:border-amber-400"
            />
            <button
              type="button"
              onClick={() => setWeeklyBudget(Math.min(300, weeklyBudget + 5))}
              className="w-8 h-10 rounded-xl bg-[#0d1424] border border-[#223352] text-slate-300 hover:text-white font-mono font-bold text-sm flex items-center justify-center hover:bg-slate-800 cursor-pointer"
              title="Aumentar 5 séries"
            >
              +5
            </button>
          </div>
          <div className="flex items-center gap-1 mt-1.5">
            {[60, 80, 100, 120, 140].map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => setWeeklyBudget(preset)}
                className={`flex-1 py-0.5 rounded text-[10px] font-mono transition-colors cursor-pointer ${
                  weeklyBudget === preset
                    ? 'bg-amber-400/20 text-amber-300 font-bold border border-amber-400/40'
                    : 'bg-[#0b1220] hover:bg-slate-800 text-slate-400 border border-slate-800'
                }`}
              >
                {preset}
              </button>
            ))}
          </div>
        </div>

        {/* 4. Nível do Atleta */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
            <Award className="w-3.5 h-3.5 text-slate-500" />
            Nível do Atleta
          </label>
          <select
            value={level}
            onChange={(e) => setLevel(e.target.value as LevelOption)}
            className="w-full bg-[#0d1424] border border-[#223352] text-slate-200 text-xs sm:text-sm rounded-xl px-3 py-2.5 font-medium focus:outline-none focus:border-emerald-500 transition-colors cursor-pointer"
          >
            <option value="beginner">Iniciante (RIR 2 · Até 1 ano)</option>
            <option value="intermediate">Intermediário (RIR 1-2 · 1 a 3 anos)</option>
            <option value="advanced">Avançado (RIR 0-1 · +3 anos)</option>
          </select>
        </div>

        {/* 5. Equipamentos */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5">
            Equipamentos
          </label>
          <select
            value={equip}
            onChange={(e) => setEquip(e.target.value as EquipmentRequirement)}
            className="w-full bg-[#0d1424] border border-[#223352] text-slate-200 text-xs sm:text-sm rounded-xl px-3 py-2.5 font-medium focus:outline-none focus:border-emerald-500 transition-colors cursor-pointer"
          >
            <option value="full_gym">Academia Completa</option>
            <option value="cables_free">Cabos & Pesos Livres</option>
            <option value="dumbbells_only">Apenas Halteres</option>
          </select>
        </div>

        {/* 6. Descanso por Série */}
        <div>
          <label className="block text-xs font-semibold text-slate-400 mb-1.5 flex items-center gap-1.5">
            <Clock className="w-3.5 h-3.5 text-sky-400" />
            Descanso p/ Série
          </label>
          <select
            value={restSeconds}
            onChange={(e) => setRestSeconds(parseInt(e.target.value, 10) || 30)}
            className="w-full bg-[#0d1424] border border-[#223352] text-sky-300 font-mono font-bold text-xs sm:text-sm rounded-xl px-3 py-2.5 focus:outline-none focus:border-sky-400 transition-colors cursor-pointer"
          >
            <option value="30">30s (Automático)</option>
            <option value="45">45s</option>
            <option value="60">60s (1 minuto)</option>
            <option value="90">90s (1 min e meio)</option>
            <option value="120">120s (2 minutos)</option>
            <option value="180">180s (3 minutos)</option>
          </select>
        </div>
      </div>
    </div>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Volume2, VolumeX, X, ChevronUp, ChevronDown, Bell, BellOff } from 'lucide-react';
import { soundManager } from '../utils/audio';

interface RestTimerDockProps {
  initialSeconds: number;
  triggerKey: number; // Incrementing counter to reset & restart timer
  isMuted: boolean;
  onToggleMute: () => void;
}

export const RestTimerDock: React.FC<RestTimerDockProps> = ({
  initialSeconds,
  triggerKey,
  isMuted,
  onToggleMute,
}) => {
  const [timeLeft, setTimeLeft] = useState(initialSeconds);
  const [totalTime, setTotalTime] = useState(initialSeconds);
  const [isRunning, setIsRunning] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [hasStartedEver, setHasStartedEver] = useState(false);

  const prevTriggerRef = useRef(triggerKey);

  // Auto start or reset timer when triggerKey changes (e.g. set completed)
  useEffect(() => {
    if (triggerKey > 0 && triggerKey !== prevTriggerRef.current) {
      prevTriggerRef.current = triggerKey;
      setTimeLeft(initialSeconds);
      setTotalTime(initialSeconds);
      setIsRunning(true);
      setHasStartedEver(true);
      setIsMinimized(false);
    }
  }, [triggerKey, initialSeconds]);

  // Request notification permission once timer starts or mounts
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
      try {
        Notification.requestPermission();
      } catch (e) {
        // ignore
      }
    }
  }, []);

  // Timer countdown loop
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setIsRunning(false);
          soundManager.playTimerFinish();
          soundManager.vibrate([300, 150, 300, 150, 500]);

          // Disparar Notificação Local para alertar mesmo com o celular no bolso
          if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
            try {
              new Notification('⏰ Descanso Concluído — MeuTreino Pro', {
                body: 'Seu tempo de descanso acabou! Hora da próxima série, bora!',
                tag: 'rest-timer-alert',
              });
            } catch (err) {
              console.warn('Erro ao disparar notificação:', err);
            }
          }

          return 0;
        }

        // Warning sound at 3, 2, 1 seconds
        if (prev <= 4 && prev > 1) {
          soundManager.playWarningBeep();
          soundManager.vibrate(60);
        }

        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isRunning]);

  if (!hasStartedEver && !isRunning) return null;

  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const formattedTime = `${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;

  const progressPercent = totalTime > 0 ? ((totalTime - timeLeft) / totalTime) * 100 : 0;

  const handleAdjust = (delta: number) => {
    setTimeLeft((prev) => {
      const next = Math.max(5, prev + delta);
      setTotalTime((curr) => Math.max(curr, next));
      return next;
    });
  };

  const handlePreset = (secs: number) => {
    setTotalTime(secs);
    setTimeLeft(secs);
    setIsRunning(true);
  };

  const handleReset = () => {
    setIsRunning(false);
    setTimeLeft(totalTime);
  };

  return (
    <div className="fixed bottom-20 md:bottom-4 left-1/2 -translate-x-1/2 z-30 w-[95%] max-w-lg">
      <div className="bg-[#0b1220]/95 backdrop-blur-xl border border-sky-500/30 rounded-2xl p-3 sm:p-4 shadow-2xl shadow-black/80 ring-1 ring-sky-400/20">
        {/* Progress Bar Header */}
        <div className="w-full h-1 bg-slate-800 rounded-full overflow-hidden mb-2.5">
          <div
            className={`h-full transition-all duration-500 ${
              timeLeft <= 5 ? 'bg-amber-400 animate-pulse' : 'bg-sky-400'
            }`}
            style={{ width: `${progressPercent}%` }}
          />
        </div>

        <div className="flex items-center justify-between gap-3">
          {/* Left: Timer Display & Status */}
          <div className="flex items-center gap-3">
            <div className="flex flex-col">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                Descanso Ativo
              </span>
              <span
                className={`text-2xl sm:text-3xl font-black font-mono tracking-tight tabular-nums ${
                  timeLeft <= 5 ? 'text-amber-400' : 'text-sky-400'
                }`}
              >
                {formattedTime}
              </span>
            </div>

            {/* Quick +/- buttons */}
            <div className="flex items-center gap-1">
              <button
                type="button"
                onClick={() => handleAdjust(-15)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-bold rounded-lg border border-slate-700 transition-colors"
                title="Subtrair 15s"
              >
                -15s
              </button>
              <button
                type="button"
                onClick={() => handleAdjust(30)}
                className="px-2 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 font-mono text-xs font-bold rounded-lg border border-slate-700 transition-colors"
                title="Adicionar 30s"
              >
                +30s
              </button>
            </div>
          </div>

          {/* Right: Controls & Presets */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsRunning(!isRunning)}
              className={`p-2.5 rounded-xl font-bold flex items-center justify-center transition-all ${
                isRunning
                  ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30'
                  : 'bg-emerald-500 text-slate-950 shadow-lg shadow-emerald-500/30'
              }`}
              title={isRunning ? 'Pausar Cronômetro' : 'Continuar Cronômetro'}
            >
              {isRunning ? <Pause className="w-5 h-5 fill-current" /> : <Play className="w-5 h-5 fill-current ml-0.5" />}
            </button>

            <button
              type="button"
              onClick={handleReset}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              title="Reiniciar tempo"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={onToggleMute}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              title={isMuted ? 'Desmutar' : 'Silenciar'}
            >
              {isMuted ? <VolumeX className="w-4 h-4 text-slate-500" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
            </button>

            <button
              type="button"
              onClick={() => setIsMinimized(!isMinimized)}
              className="p-2 text-slate-400 hover:text-white"
              title={isMinimized ? 'Expandir predefinições' : 'Minimizar'}
            >
              {isMinimized ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>

            <button
              type="button"
              onClick={() => {
                if (typeof window !== 'undefined' && 'Notification' in window) {
                  Notification.requestPermission();
                }
              }}
              className="p-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition-colors"
              title="Notificações locais no bolso"
            >
              <Bell className="w-4 h-4 text-amber-400" />
            </button>

            <button
              type="button"
              onClick={() => {
                setIsRunning(false);
                setHasStartedEver(false);
              }}
              className="p-2 text-slate-500 hover:text-rose-400"
              title="Fechar Timer"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Presets Row (expandable) */}
        {!isMinimized && (
          <div className="flex items-center gap-1.5 mt-2.5 pt-2 border-t border-slate-800/80 flex-wrap">
            <span className="text-[10px] text-slate-500 font-semibold mr-1">Presets:</span>
            {[30, 45, 60, 90, 120].map((sec) => (
              <button
                key={sec}
                type="button"
                onClick={() => handlePreset(sec)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold transition-colors ${
                  totalTime === sec
                    ? 'bg-sky-500/20 text-sky-300 border border-sky-500/40'
                    : 'bg-slate-800/80 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {sec}s
              </button>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

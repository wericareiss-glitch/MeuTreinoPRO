/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Play, 
  Dumbbell, 
  Sparkles, 
  Clock, 
  Layers, 
  Flame, 
  Sliders,
  PlusCircle,
  Pencil,
  Trash2
} from 'lucide-react';
import { GeneratedWorkoutRoutine, UserProfile } from '../types/workout';
import { MUSCLE_NAMES } from '../data/exerciseDatabase';

interface WorkoutListViewProps {
  user: UserProfile;
  routines: GeneratedWorkoutRoutine[];
  activeRoutineId: string | null;
  onStartWorkout: (routine: GeneratedWorkoutRoutine) => void;
  onGoToProfileGenerator: () => void;
  onCreateManualWorkout?: () => void;
  onEditRoutine?: (routine: GeneratedWorkoutRoutine) => void;
  onDeleteRoutine?: (routineId: string) => void;
}

export const WorkoutListView: React.FC<WorkoutListViewProps> = ({
  user,
  routines,
  activeRoutineId,
  onStartWorkout,
  onGoToProfileGenerator,
  onCreateManualWorkout,
  onEditRoutine,
  onDeleteRoutine,
}) => {
  return (
    <div className="space-y-5 animate-fadeIn pb-20 max-w-4xl mx-auto">
      {/* Top Banner do Programa Semanal */}
      <div className="p-4 sm:p-5 rounded-3xl bg-[#101828] border border-[#1e2c45] shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2 mb-1.5 flex-wrap">
              <span className="text-[10px] font-mono font-black uppercase tracking-wider text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-lg border border-emerald-500/20">
                Rotina Ativa · {user.frequency || 4}x por semana
              </span>
              <span className="text-[10px] font-bold text-sky-300 bg-sky-500/10 px-2 py-0.5 rounded-lg border border-sky-500/20">
                {user.focus === 'glutes' 
                  ? '🍑 Foco Glúteos' 
                  : user.focus === 'strength' 
                  ? '🏋️ Foco Força' 
                  : user.focus === 'v_taper' 
                  ? '🔱 Foco Shape em V' 
                  : '⚖️ Foco Equilíbrio'}
              </span>
            </div>
            <h1 className="text-lg sm:text-2xl font-black text-white tracking-tight">
              Escolha o Treino de Hoje
            </h1>
            <p className="text-xs text-slate-400 mt-0.5">
              Selecione uma das rotinas abaixo ou crie seu próprio treino personalizado.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap self-start sm:self-center shrink-0">
            {onCreateManualWorkout && (
              <button
                type="button"
                onClick={onCreateManualWorkout}
                className="py-2.5 px-3.5 rounded-xl text-xs font-bold bg-emerald-500/15 hover:bg-emerald-500/25 text-emerald-300 border border-emerald-500/40 transition-all flex items-center justify-center gap-1.5 cursor-pointer shadow-sm active:scale-95"
              >
                <PlusCircle className="w-3.5 h-3.5 text-emerald-400" />
                <span>Criar Treino Manual</span>
              </button>
            )}

            <button
              type="button"
              onClick={onGoToProfileGenerator}
              className="py-2.5 px-3.5 rounded-xl text-xs font-bold bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Sliders className="w-3.5 h-3.5 text-slate-400" />
              <span>Gerar Automaticamente</span>
            </button>
          </div>
        </div>
      </div>

      {/* Se não houver treinos gerados */}
      {routines.length === 0 ? (
        <div className="p-8 sm:p-12 text-center rounded-3xl bg-[#101828] border border-slate-800">
          <Dumbbell className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white mb-1">
            Nenhum treino gerado ainda
          </h3>
          <p className="text-xs text-slate-400 max-w-md mx-auto mb-5 leading-relaxed">
            Você pode gerar automaticamente com base nos seus parâmetros científicos ou criar um treino personalizado do zero.
          </p>
          <div className="flex items-center justify-center gap-3 flex-wrap">
            {onCreateManualWorkout && (
              <button
                type="button"
                onClick={onCreateManualWorkout}
                className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl font-black text-xs bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-all shadow-lg shadow-emerald-500/25 cursor-pointer"
              >
                <PlusCircle className="w-4 h-4 text-slate-950" />
                <span>Criar Treino Manual</span>
              </button>
            )}
            <button
              type="button"
              onClick={onGoToProfileGenerator}
              className="inline-flex items-center gap-2 px-5 py-3 rounded-2xl font-bold text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-all cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-emerald-400" />
              <span>Gerar Automaticamente</span>
            </button>
          </div>
        </div>
      ) : (
        /* Lista de Treinos Gerados para Escolha */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5 sm:gap-4">
          {routines.map((routine) => {
            const isActive = activeRoutineId === routine.id;

            return (
              <div
                key={routine.id}
                className={`p-4 sm:p-5 rounded-3xl border transition-all relative overflow-hidden flex flex-col justify-between ${
                  isActive
                    ? 'bg-gradient-to-br from-emerald-950/40 via-[#0d1627] to-slate-900 border-emerald-500/60 shadow-xl shadow-emerald-500/10 ring-1 ring-emerald-400/30'
                    : 'bg-[#101828] border-[#1e2c45] hover:border-slate-700 shadow-lg'
                }`}
              >
                <div>
                  {/* Header do Card */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <div className={`w-11 h-11 rounded-2xl flex items-center justify-center font-black text-lg shrink-0 ${
                        isActive
                          ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30'
                          : 'bg-gradient-to-tr from-sky-500/20 to-teal-500/20 text-sky-300 border border-sky-500/30'
                      }`}>
                        {routine.letter}
                      </div>

                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5 flex-wrap">
                          <h2 className="text-base font-extrabold text-white tracking-tight truncate">
                            {routine.name}
                          </h2>
                          {routine.isCustom && (
                            <span className="text-[9px] font-bold text-purple-300 bg-purple-500/20 px-1.5 py-0.2 rounded border border-purple-500/30">
                              Manual
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 font-medium truncate">
                          {routine.subtitle}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-1 shrink-0">
                      {isActive && (
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold border border-emerald-500/40 animate-pulse">
                          EM ANDAMENTO
                        </span>
                      )}

                      {onEditRoutine && (
                        <button
                          type="button"
                          onClick={() => onEditRoutine(routine)}
                          className="p-1.5 rounded-xl bg-slate-800/80 text-slate-400 hover:text-white hover:bg-slate-700 transition-colors cursor-pointer"
                          title="Editar este treino"
                        >
                          <Pencil className="w-3.5 h-3.5" />
                        </button>
                      )}

                      {onDeleteRoutine && (
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Deseja realmente remover o "${routine.name}" da sua lista?`)) {
                              onDeleteRoutine(routine.id);
                            }
                          }}
                          className="p-1.5 rounded-xl bg-rose-950/20 text-rose-400 hover:bg-rose-950/40 border border-rose-900/30 transition-colors cursor-pointer"
                          title="Excluir treino"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Badges de Grupos Musculares */}
                  <div className="flex flex-wrap gap-1 mb-3">
                    {routine.muscleGroups.map((m) => (
                      <span
                        key={m}
                        className="text-[10px] font-semibold text-slate-300 bg-slate-800/80 px-2 py-0.5 rounded-lg border border-slate-700/60"
                      >
                        {MUSCLE_NAMES[m] || m}
                      </span>
                    ))}
                  </div>

                  {/* Informações de Séries & Tempo */}
                  <div className="flex items-center gap-3 text-xs text-slate-400 font-mono py-2 px-3 rounded-xl bg-[#0b1220] border border-slate-800/70 mb-3">
                    <span className="flex items-center gap-1.5">
                      <Layers className="w-3.5 h-3.5 text-sky-400" />
                      <strong className="text-white">{routine.items.length}</strong> exercícios
                    </span>
                    <span aria-hidden="true" className="text-slate-700">·</span>
                    <span className="flex items-center gap-1.5">
                      <Flame className="w-3.5 h-3.5 text-amber-400" />
                      <strong className="text-white">{routine.totalSets}</strong> séries
                    </span>
                    <span aria-hidden="true" className="text-slate-700">·</span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="w-3.5 h-3.5 text-teal-400" />
                      ~{routine.estimatedMinutes} min
                    </span>
                  </div>

                  {/* Preview dos Primeiros Exercícios */}
                  <div className="space-y-1 mb-4">
                    <span className="text-[10px] uppercase tracking-wider font-bold text-slate-500 block mb-1">
                      Exercícios programados:
                    </span>
                    {routine.items.slice(0, 4).map((it, idx) => (
                      <div key={idx} className="text-xs text-slate-300 truncate flex items-center gap-1.5">
                        <span className="text-slate-500 text-[10px]">•</span>
                        <span className="font-medium text-slate-200">{it.exercise.name}</span>
                        <span className="text-[11px] text-slate-500 font-mono">({it.sets}×{it.reps})</span>
                      </div>
                    ))}
                    {routine.items.length > 4 && (
                      <div className="text-[11px] text-slate-500 italic pl-3">
                        + mais {routine.items.length - 4} exercícios...
                      </div>
                    )}
                  </div>
                </div>

                {/* Botão de Iniciar Este Treino */}
                <button
                  type="button"
                  onClick={() => onStartWorkout(routine)}
                  className={`w-full py-3.5 px-4 rounded-2xl font-black text-xs sm:text-sm flex items-center justify-center gap-2 transition-all cursor-pointer shadow-lg active:scale-[0.98] ${
                    isActive
                      ? 'bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 shadow-emerald-500/25 ring-2 ring-emerald-400/40'
                      : 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 shadow-emerald-500/20'
                  }`}
                >
                  <Play className="w-4 h-4 fill-slate-950" />
                  <span>{isActive ? 'Continuar Treino Ativo' : 'Iniciar Este Treino'}</span>
                </button>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

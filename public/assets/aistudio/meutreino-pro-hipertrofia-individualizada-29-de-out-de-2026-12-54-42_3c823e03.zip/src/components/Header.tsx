/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { 
  Disc, 
  History, 
  Share2, 
  Volume2, 
  VolumeX, 
  Dumbbell, 
  User, 
  Sliders, 
  Home, 
  Globe,
  Zap,
  TrendingUp,
  Camera
} from 'lucide-react';
import { UserProfile } from '../types/workout';
import { TabType } from '../types/navigation';
import { useI18n } from '../utils/i18n';

interface HeaderProps {
  user: UserProfile | null;
  activeTab: TabType;
  onSelectTab: (tab: TabType) => void;
  onOpenProfile: () => void;
  onOpenVolumeBudget: () => void;
  onOpenPlateCalc: () => void;
  onOpenHistory: () => void;
  onOpenAnalytics?: () => void;
  onOpenMeasurements?: () => void;
  onShare: () => void;
  isMuted: boolean;
  onToggleMute: () => void;
  activeSetsCount: number;
  completedSetsCount: number;
  hasActiveWorkout?: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  user,
  activeTab,
  onSelectTab,
  onOpenProfile,
  onOpenVolumeBudget,
  onOpenPlateCalc,
  onOpenHistory,
  onOpenAnalytics,
  onOpenMeasurements,
  onShare,
  isMuted,
  onToggleMute,
  activeSetsCount,
  completedSetsCount,
  hasActiveWorkout = false,
}) => {
  const { t } = useI18n();

  return (
    <header className="sticky top-0 z-40 bg-[#0d1424]/95 backdrop-blur-md border-b border-[#1f2d47]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand Zone */}
        <div 
          onClick={() => onSelectTab('inicio')}
          className="flex items-center gap-2.5 shrink-0 cursor-pointer group"
          title="Ir para o Início"
        >
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-emerald-600 to-teal-400 flex items-center justify-center text-slate-950 font-black shadow-lg shadow-emerald-500/20 group-hover:scale-105 transition-transform">
            <Dumbbell className="w-5 h-5 text-slate-950 stroke-[2.5]" />
          </div>
          <div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <span className="font-extrabold text-base sm:text-lg text-white tracking-tight">
                {t.appTitle}
              </span>
              <span className="text-[10px] font-bold tracking-wider uppercase px-2 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 hidden xs:inline-block">
                {t.badgePro}
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden lg:block leading-none">
              {t.appSubtitle}
            </p>
          </div>
        </div>

        {/* Center Main Tabs (Desktop / Tablet) */}
        <nav className="hidden sm:flex items-center gap-1 bg-[#121c32] p-1 rounded-2xl border border-slate-800">
          <button
            type="button"
            onClick={() => onSelectTab('inicio')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'inicio'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            <span>{t.tabHome}</span>
          </button>

          <button
            type="button"
            onClick={() => onSelectTab('treino')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer relative ${
              activeTab === 'treino'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <Dumbbell className="w-3.5 h-3.5" />
            <span>{t.tabWorkout}</span>
          </button>

          {hasActiveWorkout && (
            <button
              type="button"
              onClick={() => onSelectTab('treino_ativo')}
              className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer relative animate-pulse ${
                activeTab === 'treino_ativo'
                  ? 'bg-gradient-to-r from-amber-400 to-orange-500 text-slate-950 shadow-md shadow-amber-500/20 font-black'
                  : 'text-amber-400 hover:text-amber-300 hover:bg-amber-500/10 font-bold'
              }`}
            >
              <Zap className="w-3.5 h-3.5 fill-amber-400" />
              <span>{t.tabActiveWorkout || 'Treino Ativo'}</span>
              {activeSetsCount > 0 && (
                <span
                  className={`text-[9px] font-mono px-1.5 py-0.2 rounded-full font-extrabold ${
                    activeTab === 'treino_ativo'
                      ? 'bg-slate-950/20 text-slate-950'
                      : 'bg-amber-400 text-slate-950'
                  }`}
                >
                  {completedSetsCount}/{activeSetsCount}
                </span>
              )}
            </button>
          )}

          <button
            type="button"
            onClick={() => onSelectTab('perfil')}
            className={`flex items-center gap-2 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'perfil'
                ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-slate-950 shadow-md shadow-emerald-500/20'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
            }`}
          >
            <User className="w-3.5 h-3.5" />
            <span>{t.tabProfile}</span>
          </button>
        </nav>

        {/* Right Tools & Profile */}
        <div className="flex items-center gap-1.5 sm:gap-2">

          {/* User Profile Button */}
          {user && (
            <button
              type="button"
              onClick={() => onSelectTab('perfil')}
              className="flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-bold bg-[#141f36] hover:bg-[#1a2947] text-emerald-300 border border-emerald-500/40 shadow-sm transition-all cursor-pointer"
              title="Acessar Perfil do Atleta"
            >
              <User className="w-3.5 h-3.5 text-emerald-400" />
              <span className="max-w-[80px] sm:max-w-[120px] truncate">{user.name}</span>
            </button>
          )}

          {/* Quick tool buttons */}
          {onOpenAnalytics && (
            <button
              type="button"
              onClick={onOpenAnalytics}
              className="hidden sm:flex items-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-xl text-xs font-semibold bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/20 transition-colors cursor-pointer"
              title="Evolução de Cargas & 1RM"
            >
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
              <span className="hidden xl:inline">Gráficos</span>
            </button>
          )}

          {onOpenMeasurements && (
            <button
              type="button"
              onClick={onOpenMeasurements}
              className="hidden sm:flex items-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-xl text-xs font-semibold bg-purple-500/10 text-purple-300 border border-purple-500/30 hover:bg-purple-500/20 transition-colors cursor-pointer"
              title="Diário de Medições & Fotos"
            >
              <Camera className="w-3.5 h-3.5 text-purple-400" />
              <span className="hidden xl:inline">Medições</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenPlateCalc}
            className="hidden md:flex items-center gap-1.5 p-2 sm:px-2.5 sm:py-1.5 rounded-xl text-xs font-semibold bg-sky-500/10 text-sky-300 border border-sky-500/30 hover:bg-sky-500/20 transition-colors cursor-pointer"
            title={t.toolPlates}
          >
            <Disc className="w-3.5 h-3.5" />
            <span className="hidden lg:inline">{t.platesBtn}</span>
          </button>

          <button
            type="button"
            onClick={onToggleMute}
            className={`p-2 rounded-xl text-xs font-medium border transition-colors cursor-pointer ${
              isMuted
                ? 'bg-slate-800/80 text-slate-400 border-slate-700'
                : 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30'
            }`}
            title={isMuted ? t.soundOff : t.soundOn}
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
          </button>

          <button
            type="button"
            onClick={onShare}
            className="p-2 rounded-xl text-xs font-medium bg-slate-800 text-slate-200 border border-slate-700 hover:bg-slate-700 transition-colors cursor-pointer"
            title={t.shareBtn}
          >
            <Share2 className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};

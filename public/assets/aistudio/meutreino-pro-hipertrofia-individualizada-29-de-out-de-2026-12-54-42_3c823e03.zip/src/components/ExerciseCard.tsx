/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { 
  Flame, 
  RefreshCw, 
  Check, 
  CheckCircle2,
  AlertCircle,
  Plus, 
  Trash2, 
  TrendingUp, 
  Clock, 
  ArrowUp, 
  ArrowDown, 
  X, 
  Pencil, 
  Zap,
  Save
} from 'lucide-react';
import { WorkoutItem, WorkoutLogs, WorkoutSessionSummary } from '../types/workout';
import { MUSCLE_NAMES } from '../data/exerciseDatabase';
import { calculate1RM, safeStorage } from '../utils/storage';
import { authStorage } from '../utils/auth';
import { getOptimalProgressionSuggestion } from '../utils/progressiveOverload';

interface ExerciseCardProps {
  item: WorkoutItem;
  index: number;
  logs: WorkoutLogs;
  history: WorkoutLogs;
  sessions?: WorkoutSessionSummary[];
  onUpdateLog: (key: string, field: 'weight' | 'reps' | 'rpe' | 'rir', val: string) => void;
  onToggleSet: (key: string, restSec: number) => void;
  onOpenWarmup: (name: string, targetWeight: string) => void;
  onOpenSwap: (index: number) => void;
  onAddSet: (index: number) => void;
  onRemoveSet: (index: number) => void;
  onUpdateRest?: (index: number, newRest: number) => void;
  onOpenAnalytics?: (exerciseName: string) => void;
  canMoveUp?: boolean;
  canMoveDown?: boolean;
  onMoveUp?: (index: number) => void;
  onMoveDown?: (index: number) => void;
  onDeleteExercise?: (index: number) => void;
}

// Botões Toggle segmentados compactos: RIR 0-4 vinculado bidirecionalmente a RPE 10-6
const INTENSITY_TOGGLES = [
  { rir: '0', rpe: '10', rirLabel: 'R0', rpeLabel: '@10', title: 'RIR 0 ↔ RPE 10 (Falha Total)' },
  { rir: '1', rpe: '9', rirLabel: 'R1', rpeLabel: '@9', title: 'RIR 1 ↔ RPE 9 (1 rep em reserva)' },
  { rir: '2', rpe: '8', rirLabel: 'R2', rpeLabel: '@8', title: 'RIR 2 ↔ RPE 8 (2 reps em reserva)' },
  { rir: '3', rpe: '7', rirLabel: 'R3', rpeLabel: '@7', title: 'RIR 3 ↔ RPE 7 (3 reps em reserva)' },
  { rir: '4', rpe: '6', rirLabel: 'R4', rpeLabel: '@6', title: 'RIR 4 ↔ RPE 6 (4 reps em reserva)' },
];

export const ExerciseCard: React.FC<ExerciseCardProps> = ({
  item,
  index,
  logs,
  history,
  sessions = [],
  onUpdateLog,
  onToggleSet,
  onOpenWarmup,
  onOpenSwap,
  onAddSet,
  onRemoveSet,
  onUpdateRest,
  onOpenAnalytics,
  canMoveUp = false,
  canMoveDown = false,
  onMoveUp,
  onMoveDown,
  onDeleteExercise,
}) => {
  const [expandedSets, setExpandedSets] = useState<Record<string, boolean>>({});

  const ex = item.exercise;
  const muscleName = MUSCLE_NAMES[item.muscleKey] || item.muscleKey;

  // 1. Estado local para inputs com mecanismo de auto-save debounced contínuo
  const [localLogs, setLocalLogs] = useState<Record<string, { weight: string; reps: string; rpe: string; rir: string }>>(() => {
    const initial: Record<string, { weight: string; reps: string; rpe: string; rir: string }> = {};
    for (let s = 1; s <= item.sets; s++) {
      const k = `${ex.id}_${s}`;
      const log = logs[k];
      initial[k] = {
        weight: log?.weight || '',
        reps: log?.reps || '',
        rpe: log?.rpe || '',
        rir: log?.rir || '',
      };
    }
    return initial;
  });

  // Estado visual do auto-salvamento: 'idle' | 'saving' | 'saved'
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const pendingUpdatesRef = useRef<Map<string, { field: 'weight' | 'reps'; value: string }>>(new Map());

  // 2. Toggle de ativação do Smart Rest automático para RIR 0 ou 1
  const [isSmartRestEnabled, setIsSmartRestEnabled] = useState<boolean>(() => {
    return safeStorage.get(`smart_rest_enabled_${ex.id}`, true);
  });
  const autoRestAppliedSetsRef = useRef<Set<string>>(new Set());

  // Sincroniza estado local quando as logs dos props mudarem externamente (sem sobrescrever digitação ativa)
  useEffect(() => {
    if (autoSaveStatus === 'saving') return;
    setLocalLogs((prev) => {
      const next = { ...prev };
      let changed = false;
      for (let s = 1; s <= item.sets; s++) {
        const k = `${ex.id}_${s}`;
        const ext = logs[k];
        if (ext) {
          if (
            (ext.weight !== undefined && ext.weight !== next[k]?.weight) ||
            (ext.reps !== undefined && ext.reps !== next[k]?.reps) ||
            (ext.rpe !== undefined && ext.rpe !== next[k]?.rpe) ||
            (ext.rir !== undefined && ext.rir !== next[k]?.rir)
          ) {
            next[k] = {
              weight: ext.weight || '',
              reps: ext.reps || '',
              rpe: ext.rpe || '',
              rir: ext.rir || '',
            };
            changed = true;
          }
        }
      }
      return changed ? next : prev;
    });
  }, [logs, item.sets, ex.id, autoSaveStatus]);

  // Limpa debounce ao desmontar
  useEffect(() => {
    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
      }
    };
  }, []);

  // Helper de persistência imediata no storage isolado
  const persistLogsToStorageDirectly = (
    logKey: string,
    partial: Partial<{ weight: string; reps: string; rpe: string; rir: string; done: boolean }>
  ) => {
    try {
      const activeUser = authStorage.getActiveUser();
      const storageKey = activeUser ? `alex_u_${activeUser.id}_current_logs` : 'alex_guest_current_logs';
      const stored = safeStorage.get<WorkoutLogs>(storageKey, {});
      stored[logKey] = {
        ...(stored[logKey] || { done: false, weight: '', reps: '' }),
        ...partial,
        timestamp: Date.now(),
      };
      safeStorage.set(storageKey, stored);
    } catch {
      // Storage safe fallback
    }
  };

  // Mecanismo debounced de digitação sem depender de submissão explícita
  const handleInputChange = (logKey: string, field: 'weight' | 'reps', value: string) => {
    // 1. Atualização instantânea da UI local (zero latência)
    setLocalLogs((prev) => ({
      ...prev,
      [logKey]: {
        ...(prev[logKey] || { weight: '', reps: '', rpe: '', rir: '' }),
        [field]: value,
      },
    }));

    pendingUpdatesRef.current.set(`${logKey}_${field}`, { field, value });
    setAutoSaveStatus('saving');

    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    // Auto-save debounced em 350ms
    debounceTimerRef.current = setTimeout(() => {
      // Persiste no parent via callback
      onUpdateLog(logKey, field, value);

      // Persiste diretamente no storage
      persistLogsToStorageDirectly(logKey, { [field]: value });

      pendingUpdatesRef.current.delete(`${logKey}_${field}`);
      setAutoSaveStatus('saved');

      setTimeout(() => {
        setAutoSaveStatus((curr) => (curr === 'saved' ? 'idle' : curr));
      }, 1500);
    }, 350);
  };

  // Analisador Inteligente de Sobrecarga Progressiva
  const progression = getOptimalProgressionSuggestion(ex, item.reps, history, logs, sessions);

  // Busca a última sessão que continha este exercício para comparação do histórico
  const prevSessionExercise = useMemo(() => {
    for (const sess of sessions) {
      const match = sess.completedExercises.find(
        (ce) => ce.name.toLowerCase() === ex.name.toLowerCase()
      );
      if (match && match.sets.length > 0) {
        return match;
      }
    }
    return null;
  }, [sessions, ex.name]);

  // Helper para analisar a faixa de RIR alvo do exercício (ex: "1-2", "1 a 2", "2", "0-1")
  const parseTargetRir = (targetStr: string) => {
    const matches = (targetStr || '').match(/\d+/g);
    if (matches && matches.length >= 2) {
      const min = parseInt(matches[0], 10);
      const max = parseInt(matches[1], 10);
      return { min: Math.min(min, max), max: Math.max(min, max), target: (min + max) / 2 };
    } else if (matches && matches.length === 1) {
      const val = parseInt(matches[0], 10);
      return { min: val, max: val, target: val };
    }
    return { min: 1, max: 2, target: 1.5 };
  };

  // Avalia se o RIR anterior atingiu o alvo (ícone sutil com código de cores verde/laranja)
  const getPreviousRirStatus = (sIdx: number) => {
    const targetRir = parseTargetRir(item.rir);
    const setNum = sIdx + 1;

    let evaluatedRir: number | null = null;
    let sourceText = '';

    // Prioridade 1: se for série 2 ou mais, checa a série anterior da sessão atual
    if (setNum > 1) {
      const prevKey = `${ex.id}_${setNum - 1}`;
      const prevLog = localLogs[prevKey] || logs[prevKey];
      if (prevLog?.rir !== undefined && prevLog.rir !== '') {
        const val = parseInt(prevLog.rir, 10);
        if (!isNaN(val)) {
          evaluatedRir = val;
          sourceText = `Série anterior (#${setNum - 1})`;
        }
      }
    }

    // Prioridade 2: se a série atual já possui RIR preenchido
    const currKey = `${ex.id}_${setNum}`;
    const currLog = localLogs[currKey] || logs[currKey];
    if (currLog?.rir !== undefined && currLog.rir !== '') {
      const val = parseInt(currLog.rir, 10);
      if (!isNaN(val)) {
        evaluatedRir = val;
        sourceText = `Esta série (#${setNum})`;
      }
    }

    // Prioridade 3: primeira série sem RIR checa o histórico da sessão anterior
    if (evaluatedRir === null && setNum === 1) {
      const histKey = `${ex.id}_1`;
      if (history[histKey]?.rir) {
        const val = parseInt(history[histKey].rir, 10);
        if (!isNaN(val)) {
          evaluatedRir = val;
          sourceText = 'Treino anterior';
        }
      }
    }

    if (evaluatedRir === null) return null;

    const inRange = evaluatedRir >= targetRir.min && evaluatedRir <= targetRir.max;
    const diffFromTarget = Math.abs(evaluatedRir - targetRir.target);

    // Alvo atingido (check verde) se está no intervalo ou desviou em no máximo 1
    if (inRange || diffFromTarget <= 1) {
      return {
        type: 'achieved' as const,
        rir: evaluatedRir,
        title: `${sourceText}: RIR ${evaluatedRir} atingiu o alvo programado (${item.rir}). Intensidade calibrada!`,
      };
    } else {
      // Missed by more than 1 (exclamação laranja)
      const isExtremeFatigue = evaluatedRir < targetRir.min;
      return {
        type: 'missed' as const,
        rir: evaluatedRir,
        title: `${sourceText}: RIR ${evaluatedRir} desviou mais de 1 do alvo (${item.rir}). ${
          isExtremeFatigue
            ? 'Fadiga extrema (RIR baixo)! Reduza carga ou aumente descanso para evitar falha precoce.'
            : 'Muito leve (RIR alto)! Suba a carga para alcançar a zona de hipertrofia.'
        }`,
      };
    }
  };

  // Identifica se a última série concluída/registrada teve RIR 0 ou 1 (alta fadiga do SNC / falha)
  const previousSetRir = useMemo(() => {
    for (let s = item.sets; s >= 1; s--) {
      const k = `${ex.id}_${s}`;
      const l = localLogs[k] || logs[k];
      if (l && l.rir !== '' && l.rir !== undefined) {
        const val = parseInt(l.rir, 10);
        if (!isNaN(val)) {
          return { setNum: s, rir: val };
        }
      }
    }
    return null;
  }, [ex.id, item.sets, logs, localLogs]);

  // Cálculo da média histórica de volume para o exercício e para cada série
  const historicalAverages = useMemo(() => {
    const setVolumeMap: Record<number, number[]> = {};
    const allExerciseSetVolumes: number[] = [];

    for (const sess of sessions) {
      const foundEx = sess.completedExercises.find(
        (e) => e.name.toLowerCase() === ex.name.toLowerCase()
      );
      if (foundEx && foundEx.sets) {
        foundEx.sets.forEach((s, idx) => {
          const w = s.weight || 0;
          const r = s.reps || 0;
          const vol = w * r;
          if (vol > 0) {
            if (!setVolumeMap[idx]) setVolumeMap[idx] = [];
            setVolumeMap[idx].push(vol);
            allExerciseSetVolumes.push(vol);
          }
        });
      }
    }

    // Se não houver sessões salvas, verificar history
    if (allExerciseSetVolumes.length === 0) {
      for (let s = 1; s <= item.sets + 2; s++) {
        const h = history[`${ex.id}_${s}`];
        if (h?.weight && h?.reps) {
          const w = parseFloat(h.weight) || 0;
          const r = parseInt(h.reps, 10) || 0;
          const vol = w * r;
          if (vol > 0) {
            const idx = s - 1;
            if (!setVolumeMap[idx]) setVolumeMap[idx] = [];
            setVolumeMap[idx].push(vol);
            allExerciseSetVolumes.push(vol);
          }
        }
      }
    }

    const overallAvg = allExerciseSetVolumes.length > 0
      ? allExerciseSetVolumes.reduce((a, b) => a + b, 0) / allExerciseSetVolumes.length
      : null;

    const setAverages: Record<number, number> = {};
    Object.keys(setVolumeMap).forEach((k) => {
      const idx = parseInt(k, 10);
      const vols = setVolumeMap[idx];
      if (vols.length > 0) {
        setAverages[idx] = vols.reduce((a, b) => a + b, 0) / vols.length;
      }
    });

    return { overallAvg, setAverages };
  }, [sessions, ex.name, ex.id, history, item.sets]);

  // Compara dinamicamente o volume da série atual contra a média histórica (seta verde se subindo, traço neutro se estável)
  const getVolumeComparisonAgainstHistoricalAverage = (
    sIdx: number,
    currWeightStr: string,
    currRepsStr: string
  ) => {
    const currW = parseFloat(currWeightStr) || 0;
    const currR = parseInt(currRepsStr, 10) || 0;
    const currVol = currW * currR;

    const histAvg = historicalAverages.setAverages[sIdx] || historicalAverages.overallAvg;

    if (!histAvg || histAvg <= 0) {
      return {
        status: 'stable' as const,
        iconType: 'dash' as const,
        tooltip: 'Linha de base inicial deste exercício (sem histórico suficiente)',
      };
    }

    if (currVol === 0) {
      // Se apenas o peso foi digitado, projeta com a repetição mínima alvo
      const targetRepsNum = parseInt(item.reps.split('a')[0] || item.reps || '10', 10);
      if (currW > 0 && targetRepsNum > 0) {
        const estimatedVol = currW * targetRepsNum;
        if (estimatedVol > histAvg * 1.02) {
          const percentIncrease = Math.round(((estimatedVol - histAvg) / histAvg) * 100);
          return {
            status: 'increasing' as const,
            iconType: 'arrow' as const,
            tooltip: `Volume estimado (~${estimatedVol.toFixed(0)}kg) superior à média histórica (${histAvg.toFixed(0)}kg) (+${percentIncrease}%)`,
          };
        }
      }
      return {
        status: 'stable' as const,
        iconType: 'dash' as const,
        tooltip: `Média histórica de volume: ${histAvg.toFixed(0)}kg`,
      };
    }

    // Compara volume real registrado
    const ratio = currVol / histAvg;
    if (ratio > 1.02) {
      const percentIncrease = Math.round(((currVol - histAvg) / histAvg) * 100);
      return {
        status: 'increasing' as const,
        iconType: 'arrow' as const,
        tooltip: `Volume da série (${currVol.toFixed(0)}kg) subindo vs média histórica (${histAvg.toFixed(0)}kg) (+${percentIncrease}%)`,
      };
    } else {
      return {
        status: 'stable' as const,
        iconType: 'dash' as const,
        tooltip: `Volume da série (${currVol.toFixed(0)}kg) estável em relação à média histórica (${histAvg.toFixed(0)}kg)`,
      };
    }
  };

  // Lógica Dinâmica de Comparação de Carga da Sessão Anterior para cada série
  const getWeightComparison = (sIdx: number, currWeightStr: string) => {
    let prevWeight: number | null = null;
    let prevReps: number | null = null;

    if (prevSessionExercise && prevSessionExercise.sets[sIdx]) {
      prevWeight = prevSessionExercise.sets[sIdx].weight;
      prevReps = prevSessionExercise.sets[sIdx].reps;
    } else if (history[`${ex.id}_${sIdx + 1}`]?.weight) {
      prevWeight = parseFloat(history[`${ex.id}_${sIdx + 1}`].weight);
      prevReps = parseInt(history[`${ex.id}_${sIdx + 1}`].reps || '0', 10);
    }

    const currWeight = parseFloat(currWeightStr);
    const hasCurr = !isNaN(currWeight) && currWeight > 0;
    const hasPrev = prevWeight !== null && !isNaN(prevWeight) && prevWeight > 0;

    if (hasPrev) {
      if (hasCurr) {
        const diff = Math.round((currWeight - prevWeight!) * 10) / 10;
        if (diff > 0) {
          return {
            direction: 'up' as const,
            diff,
            prevWeight,
            label: `+${diff}k`,
            color: 'text-emerald-400',
            bgColor: 'bg-emerald-500/15 border-emerald-500/30',
            title: `Carga aumentou +${diff}kg em relação ao treino anterior (${prevWeight}kg)!`,
            shouldIncrease: true,
          };
        } else if (diff < 0) {
          return {
            direction: 'down' as const,
            diff,
            prevWeight,
            label: `${diff}k`,
            color: 'text-amber-400',
            bgColor: 'bg-amber-500/15 border-amber-500/30',
            title: `Carga diminuiu ${Math.abs(diff)}kg em relação ao treino anterior (${prevWeight}kg).`,
            shouldIncrease: false,
          };
        } else {
          // Carga igual à anterior: verificar se o histórico indica que deve subir carga
          const shouldIncrease = progression.status === 'progress' || (prevReps !== null && prevReps >= 8);
          return {
            direction: shouldIncrease ? ('up' as const) : ('equal' as const),
            diff: 0,
            prevWeight,
            label: shouldIncrease ? `Subir (${progression.suggestedWeight}k)` : `= ${prevWeight}k`,
            color: shouldIncrease ? 'text-emerald-400' : 'text-slate-400',
            bgColor: shouldIncrease ? 'bg-emerald-500/15 border-emerald-500/30' : 'bg-slate-800/60 border-slate-700/60',
            title: shouldIncrease 
              ? `Histórico indica que você deve subir a carga hoje! Meta: ${progression.suggestedWeight}kg.`
              : `Mesma carga da sessão anterior (${prevWeight}kg).`,
            shouldIncrease,
          };
        }
      } else {
        // Carga ainda não digitada: sinaliza proativamente se deve subir carga baseado no histórico
        const shouldIncrease = progression.status === 'progress' || (prevReps !== null && prevReps >= 8);
        return {
          direction: shouldIncrease ? ('up' as const) : ('equal' as const),
          diff: 0,
          prevWeight,
          label: shouldIncrease ? `Subir (${progression.suggestedWeight}k)` : `${prevWeight}k`,
          color: shouldIncrease ? 'text-emerald-400' : 'text-slate-500',
          bgColor: shouldIncrease ? 'bg-emerald-500/10 border-emerald-500/25' : 'bg-slate-800/40 border-slate-700/40',
          title: shouldIncrease
            ? `Treino anterior: ${prevWeight}kg com meta batida! Histórico recomenda subir para ${progression.suggestedWeight}kg.`
            : `Treino anterior: ${prevWeight}kg.`,
          shouldIncrease,
        };
      }
    }

    return null;
  };

  // Identifica séries que superaram o histórico da sessão anterior
  const seriesComparison = useMemo(() => {
    let beatenCount = 0;
    for (let sIdx = 0; sIdx < item.sets; sIdx++) {
      const setNum = sIdx + 1;
      const logKey = `${ex.id}_${setNum}`;
      const setLog = logs[logKey];
      const localLog = localLogs[logKey];
      const histLog = history[logKey];

      const currW = parseFloat(localLog?.weight || setLog?.weight || '0') || 0;
      const currR = parseInt(localLog?.reps || setLog?.reps || '0', 10) || 0;
      const currVol = currW * currR;

      let histW = 0;
      let histR = 0;
      if (prevSessionExercise && prevSessionExercise.sets[sIdx]) {
        histW = prevSessionExercise.sets[sIdx].weight || 0;
        histR = prevSessionExercise.sets[sIdx].reps || 0;
      } else if (histLog) {
        histW = parseFloat(histLog.weight || '0') || 0;
        histR = parseInt(histLog.reps || '0', 10) || 0;
      }
      const histVol = histW * histR;

      const hasHistory = histW > 0 && histR > 0;
      const isLogged = !!(setLog?.done || (currW > 0 && currR > 0));

      if (isLogged && hasHistory && (currW > histW || currVol > histVol || (currW === histW && currR > histR))) {
        beatenCount++;
      }
    }
    return { beatenCount };
  }, [ex.id, item.sets, logs, localLogs, history, prevSessionExercise]);

  const firstSetKey = `${ex.id}_1`;
  const firstSetWeight = localLogs[firstSetKey]?.weight || logs[firstSetKey]?.weight || '60';

  const toggleSetExpansion = (logKey: string) => {
    setExpandedSets((prev) => ({
      ...prev,
      [logKey]: !prev[logKey],
    }));
  };

  const handleAdjustRest = (delta: number) => {
    if (onUpdateRest) {
      onUpdateRest(index, Math.max(15, item.rest + delta));
    }
  };

  // Alterna o toggle do Smart Rest
  const handleToggleSmartRest = () => {
    setIsSmartRestEnabled((prev) => {
      const next = !prev;
      safeStorage.set(`smart_rest_enabled_${ex.id}`, next);

      // Se ativado agora e a série anterior foi RIR 0 ou 1, aplica automaticamente +30s se ainda não aplicado
      if (next && previousSetRir && (previousSetRir.rir === 0 || previousSetRir.rir === 1)) {
        const prevKey = `${ex.id}_${previousSetRir.setNum}`;
        if (!autoRestAppliedSetsRef.current.has(prevKey)) {
          autoRestAppliedSetsRef.current.add(prevKey);
          if (onUpdateRest) {
            onUpdateRest(index, item.rest + 30);
          }
        }
      }
      return next;
    });
  };

  // Preenche RIR e RPE simultaneamente com 1 clique único e auto-salva imediatamente
  const handleSelectIntensity = (logKey: string, rirVal: string, rpeVal: string) => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
      debounceTimerRef.current = null;
    }

    setLocalLogs((prev) => ({
      ...prev,
      [logKey]: {
        ...(prev[logKey] || { weight: '', reps: '' }),
        rir: rirVal,
        rpe: rpeVal,
      },
    }));

    onUpdateLog(logKey, 'rir', rirVal);
    onUpdateLog(logKey, 'rpe', rpeVal);
    persistLogsToStorageDirectly(logKey, { rir: rirVal, rpe: rpeVal });

    // Se o Smart Rest estiver ativado e a série for em RIR 0 ou 1, adiciona automaticamente +30s de descanso
    if (isSmartRestEnabled && (rirVal === '0' || rirVal === '1')) {
      if (!autoRestAppliedSetsRef.current.has(logKey)) {
        autoRestAppliedSetsRef.current.add(logKey);
        if (onUpdateRest) {
          onUpdateRest(index, item.rest + 30);
        }
      }
    }

    setAutoSaveStatus('saved');
    setTimeout(() => {
      setAutoSaveStatus((curr) => (curr === 'saved' ? 'idle' : curr));
    }, 1500);
  };

  return (
    <div className="active-workout-card bg-[#0f172a] border border-slate-800/90 rounded-xl overflow-hidden shadow-md transition-all hover:border-slate-700">
      {/* 1. Header Denso com Indicadores de Auto-Save, Sobrecarga e Botão Smart Rest Toggle */}
      <div className="px-2.5 py-1.5 bg-[#0c1322] border-b border-slate-800/80 flex items-center justify-between gap-1.5">
        <div className="flex items-center gap-1.5 min-w-0">
          <span className="text-[9px] font-extrabold uppercase tracking-tight text-sky-400 bg-sky-500/10 px-1.5 py-0.5 rounded border border-sky-500/20 shrink-0">
            {muscleName}
          </span>
          <h3 className="text-xs sm:text-sm font-bold text-white tracking-tight truncate">
            {ex.name}
          </h3>
          <span className="text-[10px] text-slate-400 font-medium font-mono hidden sm:inline shrink-0">
            ({item.sets}s · {item.reps} · {item.rir})
          </span>

          {/* Indicador de Sobrecarga / Recomendação de Subir Carga Baseado no Histórico */}
          {progression.status === 'progress' && (
            <span 
              className="text-[9px] font-bold text-emerald-400 bg-emerald-500/15 px-1.5 py-0.5 rounded border border-emerald-500/30 flex items-center gap-1 shrink-0" 
              title={progression.reason}
            >
              <ArrowUp className="w-2.5 h-2.5 stroke-[3] text-emerald-400 animate-bounce" />
              <span className="hidden xs:inline">Subir carga:</span>
              <span>+{progression.suggestedWeight - (progression.currentWeight || 0) > 0 ? (progression.suggestedWeight - (progression.currentWeight || 0)) : 2.5}kg</span>
            </span>
          )}

          {seriesComparison.beatenCount > 0 && (
            <span className="text-[9px] font-bold text-emerald-400 bg-emerald-500/15 px-1.5 py-0.2 rounded border border-emerald-500/30 flex items-center gap-0.5 shrink-0" title="Superou a sessão anterior!">
              <Flame className="w-2.5 h-2.5 fill-emerald-400 animate-pulse" />
              <span>+2.5%</span>
            </span>
          )}

          {/* Feedback Visual do Mecanismo de Debounced Auto-save */}
          {autoSaveStatus === 'saving' && (
            <span className="flex items-center gap-1 text-[8px] font-mono text-amber-400 bg-amber-500/10 px-1.5 py-0.5 rounded border border-amber-500/20 shrink-0">
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping" />
              <span>Salvando...</span>
            </span>
          )}
          {autoSaveStatus === 'saved' && (
            <span className="flex items-center gap-0.5 text-[8px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20 shrink-0 transition-opacity">
              <Check className="w-2.5 h-2.5 stroke-[3]" />
              <span>Auto-salvo</span>
            </span>
          )}
        </div>

        {/* Ações Compactas do Exercício com Botão Toggle 'Smart Rest' */}
        <div className="flex items-center gap-1 shrink-0">
          {/* Botão Toggle 'Smart Rest': adiciona automaticamente +30s se a série anterior foi RIR 0 ou 1 */}
          <button
            type="button"
            onClick={handleToggleSmartRest}
            className={`px-2 py-0.5 rounded-md text-[10px] font-extrabold flex items-center gap-1 transition-all cursor-pointer shrink-0 border ${
              isSmartRestEnabled
                ? 'bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border-emerald-500/40 shadow-sm shadow-emerald-500/10'
                : 'bg-slate-800/80 hover:bg-slate-700 text-slate-400 border-slate-700'
            }`}
            title={
              isSmartRestEnabled
                ? 'Smart Rest ATIVO: adiciona automaticamente +30s ao descanso quando a série for RIR 0 ou 1. Clique para desativar.'
                : 'Smart Rest DESATIVADO: clique para ativar a adição automática de +30s de descanso após séries de alta intensidade (RIR 0/1).'
            }
          >
            <span
              className={`w-1.5 h-1.5 rounded-full ${
                isSmartRestEnabled ? 'bg-emerald-400 animate-pulse' : 'bg-slate-600'
              }`}
            />
            <Zap
              className={`w-2.5 h-2.5 ${
                isSmartRestEnabled ? 'fill-emerald-400 text-emerald-400' : 'text-slate-500'
              }`}
            />
            <span className="font-mono text-[9px] tracking-tight">
              Smart Rest: {isSmartRestEnabled ? 'ON' : 'OFF'}
            </span>
          </button>

          <button
            type="button"
            onClick={() => onOpenSwap(index)}
            className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-sky-500/15 text-sky-300 border border-sky-500/30 hover:bg-sky-500/25 transition-all flex items-center gap-1 cursor-pointer"
            title="Trocar exercício"
          >
            <RefreshCw className="w-2.5 h-2.5 stroke-[2.5]" />
            <span className="hidden xs:inline">Trocar</span>
          </button>

          <button
            type="button"
            onClick={() => onOpenWarmup(ex.name, firstSetWeight)}
            className="p-1 rounded-md text-amber-300 bg-amber-500/10 border border-amber-500/25 hover:bg-amber-500/20 transition-colors cursor-pointer"
            title="Aquecimento"
          >
            <Flame className="w-2.5 h-2.5" />
          </button>

          {onOpenAnalytics && (
            <button
              type="button"
              onClick={() => onOpenAnalytics(ex.name)}
              className="p-1 rounded-md text-slate-400 hover:text-white bg-slate-800 border border-slate-700 transition-colors cursor-pointer"
              title="Histórico de evolução"
            >
              <TrendingUp className="w-2.5 h-2.5 text-sky-400" />
            </button>
          )}

          <div className="flex items-center bg-[#070b14] p-0.5 rounded border border-slate-800">
            <button
              type="button"
              disabled={!canMoveUp}
              onClick={() => onMoveUp?.(index)}
              className={`p-0.5 rounded transition-colors ${canMoveUp ? 'text-slate-300 hover:text-white cursor-pointer' : 'text-slate-700 cursor-not-allowed'}`}
              title="Mover para cima"
            >
              <ArrowUp className="w-2.5 h-2.5" />
            </button>
            <button
              type="button"
              disabled={!canMoveDown}
              onClick={() => onMoveDown?.(index)}
              className={`p-0.5 rounded transition-colors ${canMoveDown ? 'text-slate-300 hover:text-white cursor-pointer' : 'text-slate-700 cursor-not-allowed'}`}
              title="Mover para baixo"
            >
              <ArrowDown className="w-2.5 h-2.5" />
            </button>
          </div>

          {onDeleteExercise && (
            <button
              type="button"
              onClick={() => {
                if (confirm(`Remover "${ex.name}" deste treino?`)) onDeleteExercise(index);
              }}
              className="p-1 rounded-md text-rose-400 hover:bg-rose-950/40 bg-rose-950/20 border border-rose-900/30 transition-colors cursor-pointer"
              title="Remover exercício"
            >
              <X className="w-2.5 h-2.5" />
            </button>
          )}
        </div>
      </div>

      {/* 2. Grid com repeat(1, minmax(0, 1fr)) em telas pequenas, gap de 2px e Fontes Condensadas */}
      <div className="p-1.5 space-y-1">
        {Array.from({ length: item.sets }).map((_, sIdx) => {
          const setNum = sIdx + 1;
          const logKey = `${ex.id}_${setNum}`;
          const setLog = logs[logKey] || { weight: '', reps: '', rpe: '', rir: '', done: false };
          const localLog = localLogs[logKey] || { weight: setLog.weight || '', reps: setLog.reps || '', rpe: setLog.rpe || '', rir: setLog.rir || '' };
          const currWeightVal = localLog.weight !== undefined ? localLog.weight : setLog.weight;
          const currRepsVal = localLog.reps !== undefined ? localLog.reps : setLog.reps;

          const est1RM = calculate1RM(currWeightVal, currRepsVal);
          const isExpanded = !!expandedSets[logKey];

          // Indicador visual de comparação de carga com o treino anterior
          const weightComp = getWeightComparison(sIdx, currWeightVal);

          // Ícone sutil com código de cores comparando o volume da série atual contra a média histórica
          const volComp = getVolumeComparisonAgainstHistoricalAverage(sIdx, currWeightVal, currRepsVal);

          // Ícone sutil com código de cores indicando se o RIR anterior atingiu o alvo
          const rirStatus = getPreviousRirStatus(sIdx);

          // A) SÉRIE CONCLUÍDA
          if (setLog.done && !isExpanded) {
            return (
              <div
                key={logKey}
                className="grid grid-cols-1 sm:grid-cols-2 gap-[2px] items-center p-1 rounded-md bg-[#091120] border border-emerald-500/30 transition-all text-xs"
                style={{ gridTemplateColumns: 'repeat(1, minmax(0, 1fr))' }}
              >
                {/* Linha 1: Check, Série #, Peso, Ícone de Tendência Histórica, Reps, Ícone RIR e Carga */}
                <div className="flex items-center justify-between gap-1">
                  <div className="flex items-center gap-1 bg-[#060c18] px-1.5 py-0.5 rounded border border-emerald-500/20 font-mono text-[11px] tracking-tighter flex-1 min-w-0">
                    <span className="w-3.5 h-3.5 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-black text-[8px] shrink-0">
                      ✓
                    </span>
                    <span className="font-bold text-white shrink-0">#{setNum}</span>
                    <span className="text-emerald-300 font-extrabold ml-1 truncate">{currWeightVal || '0'} kg</span>

                    {/* Ícone sutil com código de cores comparando contra a média histórica */}
                    {volComp.iconType === 'arrow' ? (
                      <span
                        className="inline-flex items-center text-emerald-400 cursor-help shrink-0"
                        title={volComp.tooltip}
                      >
                        <TrendingUp className="w-2.5 h-2.5 stroke-[3] text-emerald-400" />
                      </span>
                    ) : (
                      <span
                        className="inline-flex items-center text-slate-500 font-mono text-[9px] font-black cursor-help shrink-0"
                        title={volComp.tooltip}
                      >
                        —
                      </span>
                    )}

                    <span className="text-slate-300 font-medium ml-1 truncate">× {currRepsVal || '0'}</span>

                    {/* Ícone sutil de status de RIR */}
                    {rirStatus && (
                      <span
                        className="inline-flex items-center shrink-0 cursor-help ml-0.5"
                        title={rirStatus.title}
                      >
                        {rirStatus.type === 'achieved' ? (
                          <CheckCircle2 className="w-3 h-3 text-emerald-400 stroke-[2.5]" />
                        ) : (
                          <AlertCircle className="w-3 h-3 text-orange-400 stroke-[2.5]" />
                        )}
                      </span>
                    )}

                    {/* Indicador visual de comparação de carga com o treino anterior */}
                    {weightComp && (
                      <span
                        className={`inline-flex items-center gap-0.5 px-1 py-0.2 rounded border font-mono text-[8px] font-bold shrink-0 transition-all ${weightComp.bgColor} ${weightComp.color}`}
                        title={weightComp.title}
                      >
                        {weightComp.direction === 'up' && (
                          <ArrowUp className="w-2.5 h-2.5 stroke-[3] text-emerald-400" />
                        )}
                        {weightComp.direction === 'down' && (
                          <ArrowDown className="w-2.5 h-2.5 stroke-[3] text-amber-400" />
                        )}
                        {weightComp.direction === 'equal' && (
                          <span className="text-[7px] text-slate-400">↔</span>
                        )}
                        <span className="truncate">{weightComp.label}</span>
                      </span>
                    )}

                    {est1RM && (
                      <span className="text-[8px] text-slate-500 ml-auto hidden xs:inline shrink-0">
                        1RM ~{est1RM}k
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-[2px] shrink-0">
                    <button
                      type="button"
                      onClick={() => toggleSetExpansion(logKey)}
                      className="h-[22px] px-1.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-mono text-[9px] tracking-tighter flex items-center justify-center gap-1 transition-colors cursor-pointer"
                      title="Editar carga/reps"
                    >
                      <Pencil className="w-2.5 h-2.5" />
                      <span>Editar</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => onToggleSet(logKey, item.rest)}
                      className="h-[22px] px-1.5 rounded bg-slate-800/80 hover:bg-slate-700 text-slate-400 hover:text-emerald-300 font-mono text-[9px] tracking-tighter transition-colors cursor-pointer"
                      title="Reabrir série"
                    >
                      Refazer
                    </button>
                  </div>
                </div>

                {/* Linha 2: Grupo de Botões Toggle Segmentados RIR 0-4 / RPE 10-6 com margem negativa */}
                <div className="flex items-center -my-0.5">
                  <div className="w-full inline-flex p-[1px] bg-[#060c18] rounded border border-slate-800 shadow-inner">
                    {INTENSITY_TOGGLES.map((t) => {
                      const isSelected = (localLog.rir || setLog.rir) === t.rir || (localLog.rpe || setLog.rpe) === t.rpe;
                      return (
                        <button
                          key={t.rir}
                          type="button"
                          onClick={() => handleSelectIntensity(logKey, t.rir, t.rpe)}
                          className={`flex-1 py-1 text-center transition-all duration-200 cursor-pointer rounded-[3px] font-mono tracking-tighter ${
                            isSelected
                              ? 'bg-amber-400 text-slate-950 font-black shadow-sm ring-1 ring-amber-300 scale-[1.02]'
                              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                          }`}
                          title={t.title}
                        >
                          <span className="text-[8px] font-black leading-none block">{t.rirLabel}</span>
                          <span className="text-[7px] leading-none block opacity-80">{t.rpeLabel}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>
            );
          }

          // B) SÉRIE PENDENTE / EXPANDIDA (Com auto-save debounced, ícone comparativo de volume, ícone sutil de RIR e indicador de carga)
          return (
            <div
              key={logKey}
              className={`grid grid-cols-1 sm:grid-cols-2 gap-[2px] items-center p-1 rounded-md border transition-all ${
                setLog.done
                  ? 'bg-[#091120] border-emerald-500/40'
                  : 'bg-[#0a0f1d] border-slate-800/80 hover:border-slate-700'
              }`}
              style={{ gridTemplateColumns: 'repeat(1, minmax(0, 1fr))' }}
            >
              {/* Linha 1: Série #, Carga, Ícone comparativo de média histórica, Indicador de Carga Anterior, Repetições, Ícone RIR e Botão OK */}
              <div className="flex items-center justify-between gap-1">
                <div className="flex items-center gap-1 bg-[#070b14] px-1.5 py-0.5 rounded border border-slate-800 flex-1 min-w-0">
                  <span className="font-mono font-black text-[10px] text-sky-400 shrink-0">#{setNum}</span>
                  
                  <input
                    type="number"
                    inputMode="decimal"
                    step="0.5"
                    placeholder="kg"
                    value={currWeightVal}
                    onChange={(e) => handleInputChange(logKey, 'weight', e.target.value)}
                    className="w-full bg-transparent font-mono font-bold text-white text-[11px] tracking-tight text-center focus:outline-none min-w-[32px]"
                  />
                  <span className="text-[9px] font-mono text-slate-400 shrink-0">kg</span>

                  {/* Ícone sutil ao lado do input de peso comparando volume contra média histórica */}
                  {volComp.iconType === 'arrow' ? (
                    <span
                      className="inline-flex items-center text-emerald-400 cursor-help shrink-0"
                      title={volComp.tooltip}
                    >
                      <TrendingUp className="w-2.5 h-2.5 stroke-[3] text-emerald-400" />
                    </span>
                  ) : (
                    <span
                      className="inline-flex items-center text-slate-500 font-mono text-[9px] font-black cursor-help shrink-0"
                      title={volComp.tooltip}
                    >
                      —
                    </span>
                  )}

                  {/* Indicador visual com ícone de seta atualizado dinamicamente pela comparação com o treino anterior */}
                  {weightComp && (
                    <span
                      className={`inline-flex items-center gap-0.5 px-1 py-0.2 rounded border font-mono text-[8px] font-bold shrink-0 transition-all ${weightComp.bgColor} ${weightComp.color}`}
                      title={weightComp.title}
                    >
                      {weightComp.direction === 'up' && (
                        <ArrowUp className={`w-2.5 h-2.5 stroke-[3] ${weightComp.color} ${weightComp.shouldIncrease ? 'animate-bounce' : ''}`} />
                      )}
                      {weightComp.direction === 'down' && (
                        <ArrowDown className={`w-2.5 h-2.5 stroke-[3] ${weightComp.color}`} />
                      )}
                      {weightComp.direction === 'equal' && (
                        <span className="text-[7px] text-slate-400">↔</span>
                      )}
                      <span className="truncate max-w-[55px] sm:max-w-none">{weightComp.label}</span>
                    </span>
                  )}
                </div>

                <div className="flex items-center gap-1 bg-[#070b14] px-1.5 py-0.5 rounded border border-slate-800 flex-1 min-w-0">
                  <input
                    type="number"
                    inputMode="numeric"
                    placeholder="reps"
                    value={currRepsVal}
                    onChange={(e) => handleInputChange(logKey, 'reps', e.target.value)}
                    className="w-full bg-transparent font-mono font-bold text-white text-[11px] tracking-tight text-center focus:outline-none min-w-[32px]"
                  />
                  <span className="text-[9px] font-mono text-slate-400 shrink-0">reps</span>

                  {/* Ícone sutil com código de cores: check verde (alvo atingido) ou exclamação laranja (desvio > 1) */}
                  {rirStatus && (
                    <span
                      className="inline-flex items-center shrink-0 cursor-help"
                      title={rirStatus.title}
                    >
                      {rirStatus.type === 'achieved' ? (
                        <CheckCircle2 className="w-3 h-3 text-emerald-400 stroke-[2.5]" />
                      ) : (
                        <AlertCircle className="w-3 h-3 text-orange-400 stroke-[2.5] animate-pulse" />
                      )}
                    </span>
                  )}

                  {est1RM && (
                    <span className="text-[8px] font-mono text-sky-400/80 shrink-0 hidden xs:inline">
                      ~{est1RM}k
                    </span>
                  )}
                </div>

                <button
                  type="button"
                  onClick={() => {
                    // Limpa debounce pendente e salva de imediato
                    if (debounceTimerRef.current) {
                      clearTimeout(debounceTimerRef.current);
                      debounceTimerRef.current = null;
                    }
                    onUpdateLog(logKey, 'weight', currWeightVal);
                    onUpdateLog(logKey, 'reps', currRepsVal);
                    persistLogsToStorageDirectly(logKey, { weight: currWeightVal, reps: currRepsVal, done: !setLog.done });

                    // Se Smart Rest estiver ativo e série atual for RIR 0 ou 1, auto-adiciona +30s
                    const currRir = localLog.rir || setLog.rir;
                    if (isSmartRestEnabled && (currRir === '0' || currRir === '1')) {
                      if (!autoRestAppliedSetsRef.current.has(logKey)) {
                        autoRestAppliedSetsRef.current.add(logKey);
                        if (onUpdateRest) {
                          onUpdateRest(index, item.rest + 30);
                        }
                      }
                    }

                    onToggleSet(logKey, item.rest);
                    setExpandedSets((prev) => ({ ...prev, [logKey]: false }));
                  }}
                  className={`h-[24px] px-2.5 rounded flex items-center justify-center font-mono font-black text-[11px] tracking-tighter transition-all cursor-pointer gap-1 shrink-0 ${
                    setLog.done
                      ? 'bg-emerald-500 text-slate-950 shadow-sm'
                      : 'bg-emerald-600 hover:bg-emerald-500 text-white active:scale-95'
                  }`}
                  title="Concluir série"
                >
                  <Check className="w-3 h-3 stroke-[3]" />
                  <span>OK</span>
                </button>
              </div>

              {/* Linha 2: Grupo de Botões Toggle Segmentados RIR (0-4) ↔ RPE (10-6) com margem negativa */}
              <div className="flex items-center -my-0.5">
                <div className="w-full inline-flex p-[1px] bg-[#070b14] rounded border border-slate-800 shadow-inner">
                  {INTENSITY_TOGGLES.map((t) => {
                    const isSelected = (localLog.rir || setLog.rir) === t.rir || (localLog.rpe || setLog.rpe) === t.rpe;
                    return (
                      <button
                        key={t.rir}
                        type="button"
                        onClick={() => handleSelectIntensity(logKey, t.rir, t.rpe)}
                        className={`flex-1 py-1 text-center transition-all duration-200 cursor-pointer rounded-[3px] font-mono tracking-tighter ${
                          isSelected
                            ? 'bg-amber-400 text-slate-950 font-black shadow-sm ring-1 ring-amber-300 scale-[1.02]'
                            : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                        }`}
                        title={t.title}
                      >
                        <span className="text-[8px] font-black leading-none block">{t.rirLabel}</span>
                        <span className="text-[7px] leading-none block opacity-80">{t.rpeLabel}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* 3. Rodapé Denso e Compacto com Indicador de Auto-Save, Sobrecarga e Toggle Smart Rest */}
      <div className="px-2.5 py-1 bg-[#0a0f1d] border-t border-slate-800/80 flex items-center justify-between text-xs">
        <div className="flex items-center gap-1.5 flex-wrap">
          <button
            type="button"
            onClick={() => onAddSet(index)}
            className="flex items-center gap-0.5 px-2 py-0.5 text-[10px] font-semibold text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded border border-slate-700 transition-colors cursor-pointer"
          >
            <Plus className="w-2.5 h-2.5 text-emerald-400" />
            <span>Série</span>
          </button>

          {item.sets > 1 && (
            <button
              type="button"
              onClick={() => onRemoveSet(index)}
              className="p-1 text-rose-400 hover:text-rose-300 bg-rose-950/20 hover:bg-rose-950/40 rounded border border-rose-900/40 transition-colors cursor-pointer"
              title="Remover série"
            >
              <Trash2 className="w-2.5 h-2.5" />
            </button>
          )}

          {progression.status === 'progress' && (
            <button
              type="button"
              onClick={() => {
                for (let s = 1; s <= item.sets; s++) {
                  const k = `${ex.id}_${s}`;
                  if (!logs[k]?.done) {
                    handleInputChange(k, 'weight', progression.suggestedWeight.toString());
                  }
                }
              }}
              className="text-[9px] font-bold text-emerald-400 bg-emerald-500/15 hover:bg-emerald-500/25 px-1.5 py-0.2 rounded border border-emerald-500/30 flex items-center gap-0.5 cursor-pointer font-mono"
              title="Aplicar carga sugerida de sobrecarga progressiva"
            >
              <Zap className="w-2 h-2 fill-emerald-400" />
              <span>+{progression.suggestedWeight}kg</span>
            </button>
          )}

          {/* Botão Smart Rest Toggle também acessível no rodapé */}
          <button
            type="button"
            onClick={handleToggleSmartRest}
            className={`px-2 py-0.5 text-[9px] font-black rounded border flex items-center gap-1 transition-all cursor-pointer shadow-sm shrink-0 ${
              isSmartRestEnabled
                ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/25'
                : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-200'
            }`}
            title={
              isSmartRestEnabled
                ? 'Smart Rest ativo: descanso aumentado automaticamente em +30s após RIR 0 ou 1'
                : 'Clique para ativar o Smart Rest automático (+30s após RIR 0/1)'
            }
          >
            <Zap
              className={`w-2.5 h-2.5 ${
                isSmartRestEnabled ? 'fill-emerald-400 text-emerald-400' : 'text-slate-500'
              }`}
            />
            <span className="font-mono">
              Smart Rest {isSmartRestEnabled ? 'ATIVO (+30s)' : 'DESLIGADO'}
            </span>
          </button>

          <span className="text-[8px] text-slate-500 font-mono hidden sm:inline-flex items-center gap-0.5" title="Seus dados são salvos continuamente de forma automática sem precisar clicar em salvar">
            <Save className="w-2 h-2 text-slate-600" />
            <span>auto-save ativo</span>
          </span>
        </div>

        {/* Descanso Compacto com Controles */}
        <div className="flex items-center gap-1 text-[10px] text-slate-400 font-mono shrink-0">
          <Clock className="w-2.5 h-2.5 text-sky-400" />
          <button
            type="button"
            onClick={() => handleAdjustRest(-15)}
            className="w-3.5 h-3.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center cursor-pointer border border-slate-700 text-[9px]"
            title="-15s"
          >
            -
          </button>
          <span className="text-white font-bold">{item.rest}s</span>
          <button
            type="button"
            onClick={() => handleAdjustRest(15)}
            className="w-3.5 h-3.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 flex items-center justify-center cursor-pointer border border-slate-700 text-[9px]"
            title="+15s"
          >
            +
          </button>
        </div>
      </div>
    </div>
  );
};
